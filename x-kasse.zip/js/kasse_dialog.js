function PlaySound(success)
{
    if(success==1)
    {
        var audio = new Audio('sounds/2.wav');
        audio.play();
    }
    else
    {
        var audio = new Audio('sounds/error.wav');
        audio.play();
    }

}
function RefreshVorgang()
{
    //location.reload();
    window.location = "index.php?v=0";
}
function AbschlussVorbereiten(ZahlungArt,ZielBeleg)
{
    if(ZielBeleg=="STORNO")
    {
        AbschlussVorgang(ZahlungArt,ZielBeleg);
    }
    else if(ZielBeleg=="VERKAUF")
    {
        if(ZahlungArt=="EC")
        {
            AbschlussVorgang(ZahlungArt,ZielBeleg);
        }
        else if(ZahlungArt=="BAR")
        {
            $(".TabbedOnTabWechselgeld").click();
            //$("#dialog-confirm>p>.kasse-dialog").html("<h4>Vorgang "+ ZahlungArt + " abschließen?</h4>");
            return false;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

}
function AbschlussVorgang(ZahlungArt,ZielBeleg)
{

    if(ZielBeleg=="STORNO")
    {
        $("#dialog-confirm>p>.kasse-dialog").html("<h4>Vorgang stornieren?</h4> <p>Grund: <input type=\"text\" id=\"StornoTotalGrund\"></p>");
    }
    else if(ZielBeleg=="VERKAUF")
    {
        if(ZahlungArt=="EC")
        {
            $("#dialog-confirm>p>.kasse-dialog").html("<h4>Vorgang "+ ZahlungArt + " abschließen?</h4><p>EC-BelegNr.: <input type=\"text\" id=\"ECBelegNrEingabe\"></p>");
        }
        else
        {
            $("#dialog-confirm>p>.kasse-dialog").html("<h4>Vorgang "+ ZahlungArt + " abschließen?</h4>");
        }
    }
    else
    {
        return false;
    }



    $("#dialog-confirm").dialog({
         resizable: false,
         closeOnEscape: false,
         height: "auto",
         width: 400,
         modal: true,
         position: { my: "center top", at: "center top", of: window },
         show: {
               effect: "fade",
               duration: 100
         },
         buttons:
         {
           FERTIG: function() {

               if(ZahlungArt=="EC")
               {
                   if($("#ECBelegNrEingabe").val()=="")
                   {
                        alert("EC-Beleg Eingabe überprüfen.");
                        $( this ).dialog( "close" );
                        return false;
                   }

               }


               var data = new Array();
                   data.push({name: "do",     value: "AbschlussVorgang" });
                   data.push({name: "VorgangID",     value: $("#VorgangID").val() });
                   data.push({name: "ZahlungArt",     value: ZahlungArt });
                   data.push({name: "VorgangArt",     value: ZielBeleg });
                   data.push({name: "ControlSummeBar",     value: parseFloat($("#WechselgeldHelperErhalten").val() /100) });
                   data.push({name: "ControlSummeBrutto",     value: parseFloat($("#WechselgeldHelperSummeBrutto").val()) });
                   data.push({name: "ControlECBeleg",     value: $("#ECBelegNrEingabe").val() });
                   data.push({name: "ControlBemerkung",     value: $("#StornoTotalGrund").val() });




                   $.post("ajax.php",data,
                   function(xml)
                   {
                       if($(xml).find('success').text()==1)
                       {
                           PlaySound($(xml).find('success').text());
                           $("#AjaxMeldung").html( $(xml).find('message').text() );
                           //$("#AjaxMeldung").html( $(xml).find('message').text()  );
                           RefreshVorgang();
                           alert("Wechselgeld:  " + $(xml).find('Wechselgeld').text());
                          return false;
                       }
                       else
                       {
                           PlaySound($(xml).find('success').text());
                           alert(  $(xml).find('message').text()  );
                           RefreshVorgang();
                           return false;
                       }
                       return false;
                   });


               $( this ).dialog( "close" );
               //eval($(xml).find('Javascript').first().text());
               //StoreAndDraw();
           },
           CANCEL: function() {

               $( this ).dialog( "close" );
               //DrawConfigurator();
           }
         }
       });
}
function WechselgeldBerechnen()
{
    if($("#WechselgeldHelperErhalten").val()=="")
    {
        //alert("Wieviel in bar erhalten?");
        //return false;
    }


  var wechselgeld = (parseFloat($("#WechselgeldHelperErhalten").val()) / 100) - parseFloat($("#WechselgeldHelperSummeBrutto").val());

    if(wechselgeld<0)
    {
        alert("Betrag deckt nicht die Summe");
        $("#WechselgeldHelperErhalten").val("").focus();

        return false;
    }
    else
    {
        $("#WechselgeldHelperZurueck").val(wechselgeld.toFixed(2));
    }




}


function hinzu(HinzuArray)
{
    console.log(HinzuArray);

    var data = new Array();
    data = HinzuArray;
    data.push({name: "do",     value: "Hinzu" });
    data.push({name: "VorgangID",     value: $("#VorgangID").val() });



    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            PlaySound($(xml).find('success').text());
           $("#AjaxMeldung").html("");
            BerechneVorgang();
           return false;
        }
        else
        {
            PlaySound($(xml).find('success').text());
            $("#AjaxMeldung").html( $(xml).find('message').text()  );
            BerechneVorgang();
            return false;
        }
        return false;
    });
}
function BerechneVorgang()
{
    // Diese Funktion immer ausführen, nachdem irgendetwas geändert wurde

    //$("#tabs-left").tabs( "option", "active", 0 );
    $('#tabs-left').tabs({active: 0});

    var data = new Array();
    data.push({name: "do",     value: "BerechneVorgang" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
           $("#Journal").fadeOut("fast").html( $(xml).find('Journal').text()  ).fadeIn("fast");
           $("#JournalFooter").fadeOut("fast").html( $(xml).find('JournalFooter').text()  ).fadeIn("fast");
           $("#KundenAdresseVorschau").fadeOut("fast").html( $(xml).find('KundenAdresseVorschau').text()  ).fadeIn("fast");
            $(".JournalVorschau").tablesorter();
           return false;
        }
        else
        {
            $("#Journal").fadeOut("fast").html( $(xml).find('Journal').text()  ).fadeIn("fast");
            $("#JournalFooter").fadeOut("fast").html( $(xml).find('JournalFooter').text()  ).fadeIn("fast");
            $("#KundenAdresseVorschau").fadeOut("fast").html( $(xml).find('KundenAdresseVorschau').text()  ).fadeIn("fast");
            $(".JournalVorschau").tablesorter();
            return false;
        }
        return false;
    });
}
function KasseUpdateBediener()
{

    var data = $("#form_bediener").serializeArray();
    data.push({name: "do",     value: "KasseUpdateBediener" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            //alert( $(xml).find('message').text()  );
            location.reload();
           return false;
        }
        else
        {
            alert( $(xml).find('message').text()  );
            return false;
            //
        }
        return false;
    });
}
function BonPrinterTest()
{

    var data = new Array();
    data.push({name: "do",     value: "BonPrinterTest" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            alert("Es wurde ein Druckauftrag gestartet, bitte Bon-Drucker prüfen")
           return false;
        }
        else
        {
            alert("Es wurde ein Druckauftrag gestartet, bitte Bon-Drucker prüfen")
            return false;
            //
        }
        return false;
    });
}
function Synch()
{

    var data = new Array();
    data.push({name: "do",     value: "Synch" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            //alert($(xml).find('message').text());
            $("#AjaxMeldung").html( $(xml).find('message').text()  );
           return false;
        }
        else
        {
            //alert($(xml).find('message').text());
            $("#AjaxMeldung").html( $(xml).find('message').text()  );
            return false;
            //
        }
        return false;
    });
}
function PrintBonKopie(VorgangID)
{

    var data = new Array();
    data.push({name: "do",     value: "PrintBonKopie" });
    data.push({name: "VorgangID",     value: VorgangID });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            alert("Es wurde ein Druckauftrag gestartet, bitte Bon-Drucker prüfen")
           return false;
        }
        else
        {
            alert("Es wurde ein Druckauftrag gestartet, bitte Bon-Drucker prüfen")
            return false;
            //
        }
        return false;
    });
}
function Datensicherung()
{

    var data = new Array();
    data.push({name: "do",     value: "Datensicherung" });

    $("body").addClass("loading");

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            alert( $(xml).find('message').text()  );
            location.reload();
           return false;
        }
        else
        {
            alert( $(xml).find('message').text()  );
            location.reload();
            return false;
            //
        }
        return false;
    });
}
function LadeVorgaenge()
{

    var data = new Array();
    data.push({name: "do",     value: "LadeVorgaenge" });

    $("#KasseVorgaenge").addClass("loading");

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            $("#KasseVorgaenge").html( $(xml).find('Liste').text()  );
            $("#KasseVorgaenge").removeClass("loading");
            $(".tablesort").tablesorter({
                        widthFixed : false,
                        widgets: ["filter"],
                        widgetOptions : {
                        filter_childRows : false
                        }
                    });

           return false;
        }
        else
        {
            $("#KasseVorgaenge").html( $(xml).find('Liste').text()  );
            $("#KasseVorgaenge").removeClass("loading");
            $(".tablesort").tablesorter({
                        widthFixed : false,
                        widgets: ["filter"],
                        widgetOptions : {
                        filter_childRows : false
                        }
                    });
            return false;
            //
        }
        return false;
    });
}

