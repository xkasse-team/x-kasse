function KasseLogOut()
{
    var data = new Array();
    data.push({name: "do",     value: "logout" });

    $.post("ajax.php",data,
      function(xml)
      {
        if($(xml).find('success').text()==1)
        {
            //$("#debug").html( $(xml).find('message').text()  );
            $("#kasse_html_envelope").html($(xml).find('loginform').text());
        }
        else
        {
            //$("#debug").html( $(xml).find('message').text()  );
            $("#kasse_html_envelope").html($(xml).find('loginform').text());
        }
        return false;
      });
}
function KasseLogIn()
{

    var data = new Array();
    data.push({name: "do",     value: "login" });
    data.push({name: "BenutzerKurz",     value: $("#BenutzerKurz").val() });
    data.push({name: "Passwort",     value: $("#Passwort").val() });

    $.post("ajax.php",data,
      function(xml)
      {
        if($(xml).find('success').text()==1)
        {
            $("#debug").html($(xml).find('message').text());
            window.location.replace("index.php");
        }
        else
        {
            $("#debug").html($(xml).find('message').text());
        }
        return false;
      });
}