jQuery(document).ready(function($)
{

    BerechneVorgang();

    $( "#tabs-left,#tabs-right" ).tabs();

    $(document).on("click", "#FormbyArtNr_ArtNr", function()
    {
        $("#FormbyArtNr_ArtNr").val("");
        $("#FormbyArtNr_Anzahl").val(1);

    });

    $("#FormbyArtNr_ArtNr").scannerDetection({
    	timeBeforeScanTest: 200, // wait for the next character for upto 200ms
    	//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
    	endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
    	avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
    	onComplete: function(barcode, qty)
      {
          // barcode
          var data = $("#FormbyArtNr").serializeArray();
          data.push({name: "do",     value: "scan" });
          data.push({name: "barcode",     value: barcode });

          $.post("ajax.php",data,
             function(xml)
             {
                 //alert($(xml).find('success').text());
               if($(xml).find('success').text()==1)
               {

                   //$("#FormbyArtNr_HinzuForm").html( $(xml).find('message').text()  );


                   // post: Aktion HINZU
                    var HinzuArray = new Array();
                   HinzuArray.push({name: "ArtNr",     value: $(xml).find('ArtNr').text()  });
                   HinzuArray.push({name: "Anzahl",     value: 1  });
                   HinzuArray.push({name: "Menge",     value: $(xml).find('Menge').text()  });
                   HinzuArray.push({name: "MengenEinheit",     value: $(xml).find('Mengeneinheit').text()  });
                   //HinzuArray.push({name: "P",     value: $(xml).find('EpBrutto').text()  });

                   if($("#FormbyWarengruppe").hasClass("RetourModus") || $("#FormbyArtNr").hasClass("RetourModus"))
                   {
                       HinzuArray.push({name: "P",     value: $(xml).find('EpBrutto').text() });
                       HinzuArray.push({name: "BelegInfo",     value: "RETOUR" });
                       HinzuArray.push({name: "Prefix",     value: "-" });


                   }
                   else
                   {
                       HinzuArray.push({name: "P",     value: $(xml).find('EpBrutto').text() });
                       HinzuArray.push({name: "BelegInfo",     value: "" });
                       HinzuArray.push({name: "Prefix",     value: "" });
                   }



                   hinzu(HinzuArray);
                   //PlaySound(1);

                   // Refresh Positionen...
                   BerechneVorgang();
                   // ArtNr Input setFocus
                   $("#FormbyArtNr_ArtNr").val("");
                   $("#FormbyArtNr_ArtNr").focus();

               }
               else
               {
                   PlaySound(0);
                   $("#FormbyArtNr_HinzuForm").html( $(xml).find('message').text()  );
                    $("#FormbyArtNr_ArtNr").val("");
                    $("#FormbyArtNr_ArtNr").focus();
                   //$("#FormbyArtNr_ArtNr").focus();
                   //alert(0);
               }
               return false;
             });
      }
    });

    $("#VorgangAbschliessenBar").click(function(event)
    {
        event.preventDefault();
        AbschlussVorgang("BAR","VERKAUF");
    });
    $("#AddByArtNr").click(function(event)
    {
        event.preventDefault();

        $("#FormbyArtNr_HinzuForm").html("<div class=\"loading\"></div>");

        var data = $("#FormbyArtNr").serializeArray();
        data.push({name: "do",     value: "GetHinzuForm" });
        $.post("ajax.php",data,
           function(xml)
           {
             if($(xml).find('success').text()==1)
             {
                 $("#FormbyArtNr_HinzuForm").html( $(xml).find('HinzuForm').text()  );
                 $("#Hinzu-0").focus();
             }
             else
             {
                 $("#FormbyArtNr_HinzuForm").html( $(xml).find('FoundProductsForm').text() );
                 $("#FormbyArtNr_ArtNr").focus();
             }
             return false;
           });
    });
    $("#BtnSucheKunden").click(function(event)
    {
        event.preventDefault();

        $("#KundeListe").html("<div class=\"loading\"></div>");

        var data =new Array();
        data.push({name: "do",     value: "SearchKunden" });
        data.push({name: "SucheKunden",     value: $("#SucheKunden").val() });
        $.post("ajax.php",data,
           function(xml)
           {
             if($(xml).find('success').text()==1)
             {
                 $("#KundeListe").html( $(xml).find('KundenListe').text()  );
                 $(".KundenListe").tablesorter({
                             widthFixed : false,
                             widgets: ["filter"],
                             widgetOptions : {
                             filter_childRows : false
                             }
                         });
             }
             else
             {
                 $("#KundeListe").html( $(xml).find('KundenListe').text() );
                 $(".KundenListe").tablesorter({
                                              widthFixed : false,
                                              widgets: ["filter"],
                                              widgetOptions : {
                                              filter_childRows : false
                                              }
                                          });
             }
             return false;
           });
    });
    $("#Go").click(function(event)
    {
        //obsolete
        return false;
        event.preventDefault();
        PlaySound(1);
        PlaySound(2);

        $("#dialog-confirm>p>.toxy-dialog").html("Message");
        $("#dialog-confirm").dialog({
              resizable: false,
              closeOnEscape: false,
              height: "auto",
              width: 400,
              modal: true,
              position: { my: "center top", at: "center top", of: window },
              show: {
                    effect: "fade",
                    duration: 100
              },

              buttons:
              {
                OK: function() {
                    $( this ).dialog( "close" );
                    //eval($(xml).find('Javascript').first().text());
                    //StoreAndDraw();
                },
                CANCEL: function() {

                    $( this ).dialog( "close" );
                    //DrawConfigurator();
                }
              }
            });


        //$("#debug").text( "Bitte warten..."  );

/*
        var data = $("#FormSettings").serializeArray();
        data.push({name: "do",     value: "TestProcess" });
        //data.push({name: "post_id",     value: $(this).attr("data-postid") });
        //data.push({name: "likevalue",     value: "1" });


        $.post("##basehref##ajax.php",data,
        function(xml)
        {
            //alert($(xml).find('message').text());
          if($(xml).find('success').text()==1)
          {
              $("#debug").html( $(xml).find('message').text()  );
          }
          else
          {
              $("#debug").html( $(xml).find('message').text()  );
              //location.reload();
              //alert($(this).html());
          }
          return false;
        });
        */
    });

});



// auf dynamisch generierte Elemente anwendbar:

$(document).on("click", ".TabbedOnTabWechselgeld", function()
{
    //event.preventDefault();
    $("#WechselgeldHelperSummeBrutto").val($("#JournalFooterSumTable").data("summebrutto"));
    $("#WechselgeldHelperErhalten").focus();

});
$(document).on("focusout", "#WechselgeldHelperErhalten", function()
{
    WechselgeldBerechnen();
});
$(document).on("click", "#WechselgeldHelperZurueck", function()
{
    WechselgeldBerechnen();
});
$(document).on("click", ".FoundProductItem", function()
{
    $("#ProductDetailInfo_"+$(this).data("artnr")).toggle();
    /*
        $("#FormbyArtNr_ArtNr").val($(this).data("artnr"));
        $("#AddByArtNr").click();
        */
});
$(document).on("click", ".TabbedOnTabByArtNr", function()
{
        $("#FormbyArtNr_ArtNr").focus();

        $("#RowContainsTwoColumn").addClass("Cols50x50");
        $("#RowContainsTwoColumn").removeClass("Cols33x66");
});
$(document).on("click", ".TabbedOnTabDoTheScan", function()
{
        $("#FormbyArtNr_ArtNr").focus();

        $("#RowContainsTwoColumn").addClass("Cols50x50");
        $("#RowContainsTwoColumn").removeClass("Cols33x66");
});
$(document).on("click", ".TabbedOnTabByWarengruppe", function()
{
        $("#FormbyWarengruppe_Betrag").focus();

        $("#RowContainsTwoColumn").removeClass("Cols50x50");
        $("#RowContainsTwoColumn").addClass("Cols33x66");

});
$(document).on("click", ".TabbedOnTabAdministration", function()
{
       // $("#FormbyWarengruppe_Betrag").focus();
});
$(document).on("click", ".TabbedOnTabKunde", function()
{
      $("#SucheKunden").focus();
});
$(document).on("click", ".TabbedOnTabPositionen", function()
{
      $("#FormbyArtNr_ArtNr").focus();
});
$(document).on("click", ".ButtonSelectKunden", function()
{

    var data = new Array();
       data.push({name: "do",     value: "SelectKunde" });
       data.push({name: "kundennummer",     value: $(this).data("kundennummer") });
       data.push({name: "VorgangID",     value: $("#VorgangID").val() });


       $.post("ajax.php",data,
       function(xml)
       {
           if($(xml).find('success').text()==1)
           {
               PlaySound($(xml).find('success').text());
              $("#AjaxMeldung").html("");
               //$("#TabbedOnTabKunde").click();
               BerechneVorgang();

              return false;
           }
           else
           {
               PlaySound($(xml).find('success').text());
               $("#AjaxMeldung").html( $(xml).find('message').text()  );
               BerechneVorgang();
               return false;
           }
           return false;
       });

});
$(document).on("click", ".ButtonHinzu", function()
{
    var data = new Array();

    data.push({name: "ArtNr",     value: $(this).data("artnr") });



    //data.push({name: "P",     value: $(this).data("p") });

    if($("#FormbyWarengruppe").hasClass("RetourModus") || $("#FormbyArtNr").hasClass("RetourModus"))
    {
        data.push({name: "P",     value: parseFloat($(this).data("p")) });
        data.push({name: "BelegInfo",     value: "RETOUR" });
        data.push({name: "Prefix",     value: "-" });


    }
    else
    {
        data.push({name: "P",     value: parseFloat( $(this).data("p")) });
        data.push({name: "BelegInfo",     value: "" });
        data.push({name: "Prefix",     value: "" });
    }


    data.push({name: "Menge",     value: $(this).data("ehvk") });
    data.push({name: "MengenEinheit",     value: $(this).data("mass") });
    data.push({name: "Anzahl",     value: $("#FormbyArtNr_Anzahl").val()});

    console.log(data);

    hinzu(data);



        //$("#FormbyArtNr_ArtNr").val($(this).data("artnr"));
        //$("#AddByArtNr").click();
});
$(document).on("click", ".zifferW", function()
{
    if($(this).data("taste")=="C")
    {
        $("#WechselgeldHelperErhalten").val("").focus();
        $("#WechselgeldHelperZurueck").val("");

        return false;
    }

    $("#WechselgeldHelperErhalten").val( $("#WechselgeldHelperErhalten").val()  + "" + $(this).data("taste"));
});
$(document).on("click", ".ziffer", function()
{
    if($(this).data("taste")=="C")
    {
        $("#FormbyWarengruppe_Betrag").val("");
        return false;
    }
    if($(this).data("taste")=="X")
    {
        $("#FormbyWarengruppe_Anzahl").val($("#FormbyWarengruppe_Betrag").val());
        $("#FormbyWarengruppe_Betrag").val("");
        return false;
    }
    $("#FormbyWarengruppe_Betrag").val( $("#FormbyWarengruppe_Betrag").val()  + "" + $(this).data("taste"));
});
$(document).on("click", ".TabbedOnTabRetour", function()
{

    //alert("Retour Modus Toggle");
    //FormbyArtNr_HinzuFormTopper
    //FormbyWarengruppeTopper

    $("#FormbyWarengruppe, #FormbyArtNr").toggleClass("RetourModus");

});
$(document).on("click", ".HinzuRabatt", function()
{
    alert(1);
});
$(document).on("click", ".HinzuWarengruppe ", function()
{
    var data = new Array();

    var betragWert = 0;
    betragWert = $("#FormbyWarengruppe_Betrag").val().replace(",","").trim();


    //alert($(this).data("prefix"));

    if(betragWert=="") return false;


    data.push({name: "ArtNr",     value: $(this).data("artnr") });

    if($("#FormbyWarengruppe").hasClass("RetourModus") || $("#FormbyArtNr").hasClass("RetourModus"))
    {
        if($(this).data("prefix")=="%")
        {
            return false;
        }

        data.push({name: "P",     value: parseFloat(betragWert) / 100 });
        data.push({name: "BelegInfo",     value: "RETOUR" });
        data.push({name: "Prefix",     value: "-" });
    }
    else
    {
        data.push({name: "P",     value: parseFloat(betragWert) / 100 });
        data.push({name: "BelegInfo",     value: "" });
        data.push({name: "Prefix",     value: $(this).data("prefix") });  // muss übergeben werden, kann ein % sein
    }




    data.push({name: "Menge",     value: 1 });
    //data.push({name: "ArtikelBezeichnung",     value: $(this).data("warengruppe") });
    data.push({name: "WarengruppenId",     value: $(this).data("warengruppenid") });
    data.push({name: "MengenEinheit",     value: "STK" });

    data.push({name: "Anzahl",     value: $("#FormbyWarengruppe_Anzahl").val()});

    hinzu(data);


    $("#FormbyWarengruppe_Betrag").val("").focus();


    //$("#FormbyWarengruppe_Betrag").val();
});
$(document).on("click", "#StornoLetztePosition ", function()
{
    $("#dialog-confirm>p>.kasse-dialog").html("Letzte Hinzu/Scan stornieren?");
    $("#dialog-confirm").dialog({
         resizable: false,
         closeOnEscape: false,
         height: "auto",
         width: 400,
         modal: true,
         position: { my: "center top", at: "center top", of: window },
         show: {
               effect: "fade",
               duration: 100
         },

         buttons:
         {
           OK: function() {


               var data = new Array();
                   data.push({name: "do",     value: "StornoUndo" });
                   data.push({name: "VorgangID",     value: $("#VorgangID").val() });

                   $.post("ajax.php",data,
                   function(xml)
                   {
                       if($(xml).find('success').text()==1)
                       {
                           PlaySound($(xml).find('success').text());
                           $("#AjaxMeldung").html("");
                           //$("#AjaxMeldung").html( $(xml).find('message').text()  );
                           BerechneVorgang();
                          return false;
                       }
                       else
                       {
                           PlaySound($(xml).find('success').text());
                           alert(  $(xml).find('message').text()  );
                           BerechneVorgang();
                           return false;
                       }
                       return false;
                   });


               $( this ).dialog( "close" );
               //eval($(xml).find('Javascript').first().text());
               //StoreAndDraw();
           },
           CANCEL: function() {

               $( this ).dialog( "close" );
               //DrawConfigurator();
           }
         }
       });
});





