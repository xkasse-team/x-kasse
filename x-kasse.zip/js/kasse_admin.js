// ADMIN
function ImportWarengruppen()
{
    var data = new Array();
    data.push({name: "do",     value: "ImportWarengruppen" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            location.reload();
           return true
        }
        else
        {
            alert( $(xml).find('message').text()  );
            return false;
            //
        }
        return false;
    });
}
function ImportMwSt()
{
    var data = new Array();
    data.push({name: "do",     value: "ImportMwSt" });


    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            location.reload();
           return false;
        }
        else
        {
            alert( $(xml).find('message').text()  );
            return false;
            //
        }
        return false;
    });
}
function AdminInsertBediener()
{
    //var data = new Array();
    var data = $("#form_AddBediener").serializeArray();
    data.push({name: "do",     value: "AdminInsertBediener" });

    $.post("ajax.php",data,
    function(xml)
    {
        if($(xml).find('success').text()==1)
        {
            location.reload();
           return true
        }
        else
        {
            alert( $(xml).find('message').text()  );
            return false;
            //
        }
        return false;
    });
}
function ZBerichtVorschau()
{
    var data = new Array();
        data.push({name: "do",     value: "ZBerichtVorschau" });
        $.post("ajax.php",data,
        function(xml)
        {
            if($(xml).find('success').text()==1)
            {
                $("#ZBerichtVorschau").html( $(xml).find('message').text() );
                alert("OK");
               return false;
            }
            else
            {
                alert("Fehler");
                $("#ZBerichtVorschau").html( $(xml).find('message').text() );
                return false;
            }
            return false;
        });
}
function ZBericht()
{
    $("#dialog-confirm>p>.kasse-dialog").html("<h4>Tagesabschluss durchführen?</h4>");
    $("#dialog-confirm").dialog({
         resizable: false,
         closeOnEscape: false,
         height: "auto",
         width: 400,
         modal: true,
         position: { my: "center top", at: "center top", of: window },
         show: {
               effect: "fade",
               duration: 100
         },
         buttons:
         {
           FERTIG: function() {

               var data = new Array();
                   data.push({name: "do",     value: "ZBericht" });
                   $.post("ajax.php",data,
                   function(xml)
                   {
                       if($(xml).find('success').text()==1)
                       {
                           //PlaySound($(xml).find('success').text());
                           //$("#AjaxMeldung").html( $(xml).find('message').text() );
                           alert("OK");
                         //  location.reload();
                          return false;
                       }
                       else
                       {
                           //PlaySound($(xml).find('success').text());
                           alert("Fehler");
                           $("#AjaxMeldung").html( $(xml).find('message').text() );
                           return false;
                       }
                       return false;
                   });
               $( this ).dialog( "close" );
           },
           CANCEL: function() {

               $( this ).dialog( "close" );
           }
         }
       });
}
function SwitchBenutzerStatus(UserId)
{
    var data = new Array();
        data.push({name: "do",     value: "AdminSwitchBenutzerStatus" });
        data.push({name: "UserId",     value: UserId });

       $.post("ajax.php",data,
       function(xml)
       {
           if($(xml).find('success').text()==1)
           {
                alert($(xml).find('message').text()  );
                return false
           }
           else
           {
               alert( $(xml).find('message').text()  );
               return false;
           }
           return false;
       });
}