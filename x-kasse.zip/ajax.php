<?php
session_start();
header ("content-type: text/xml;charset=utf-8");

require_once('config/config.php');
require_once('controller_db/kabimba.db.class.php');
require_once('controller_db/kabimba.pdo.class.php');
require_once('controller/ArtikelStamm.db.php');
require_once('controller/useful.php');
require_once('controller/kasse_user.php');
require_once('controller/kasse.php');
require_once('controller/kasse_dialog.php');
require_once('controller/kasse_admin.php');
require_once('controller/kasse_print.php');
require_once('controller/synch.php');
require_once('libraries_3rdparty/fpdf181/fpdf.php');
require_once('libraries_3rdparty/mysqldump-php-master/src/Ifsnop/Mysqldump/Mysqldump.php');


DB::init(KASSE_DBSERVER,KASSE_DBUSERNAME,KASSE_DBPASSWORD,KASSE_DB);


// Ausgabe nur XML
//print_r($_REQUEST);

switch (@$_REQUEST['do'])
{
    case 'login':
        $ret = kasse_user::login(@$_REQUEST);
        echo  useful::array2xml($ret);
        break;
    case 'logout':
        $ret = kasse_user::logout();
        echo  useful::array2xml($ret);
        break;
    case 'scan':
        $ret = kasse_dialog::scan();
        echo useful::array2xml($ret);
        break;
    case 'debug':
        $ret = print_r($_REQUEST,true);
        echo  useful::array2xml($ret);
        break;
    case 'GetHinzuForm':
        $ret = kasse_dialog::GetHinzuForm();
        echo  useful::array2xml($ret);
        break;
    case 'Hinzu':
        $ret = kasse_dialog::doHinzu();
        echo  useful::array2xml($ret);
        break;
    case 'BerechneVorgang':
        $ret = kasse_dialog::doBerechneVorgang('');
        echo  useful::array2xml($ret);
        break;
    case 'ImportWarengruppen':
        $ret = kasse_admin::doImportWarengruppen();
        echo  useful::array2xml($ret);
        break;
    case 'ImportMwSt':
        $ret = kasse_admin::doImportMwSt();
        echo  useful::array2xml($ret);
        break;
    case 'AdminInsertBediener':
        $ret = kasse_admin::doAdminInsertBediener();
        echo  useful::array2xml($ret);
        break;
    case 'AdminSwitchBenutzerStatus':
        $ret = kasse_admin::doAdminSwitchBenutzerStatus();
        echo  useful::array2xml($ret);
        break;
    case 'KasseUpdateBediener':
        $ret = kasse_dialog::doKasseUpdateBediener();
        echo  useful::array2xml($ret);
        break;
    case 'StornoUndo':
        $ret = kasse_dialog::doStornoUndo();
        echo  useful::array2xml($ret);
        break;
    case 'SearchKunden':
        $ret = kasse_dialog::doSearchKunden();
        echo  useful::array2xml($ret);
        break;
    case 'SelectKunde':
        $ret = kasse_dialog::doSelectKunden();
        echo  useful::array2xml($ret);
        break;
    case 'ShowKunde':
        $ret = kasse_dialog::doShowKunde();
        echo  useful::array2xml($ret);
        break;
    case 'AbschlussVorgang':
        $ret = kasse_dialog::doAbschlussVorgang();
        echo  useful::array2xml($ret);
        break;
    case 'AbschlussVorbereiten':
        $ret = kasse_dialog::doAbschlussVorgang();
        echo  useful::array2xml($ret);
        break;
    case 'ZBericht':
        $ret = kasse::doZBericht(0);
        echo  useful::array2xml($ret);
        break;
    case 'ZBerichtVorschau':
        $ret = kasse::doZBericht(1);
        echo  useful::array2xml($ret);
        break;
    case 'BonPrinterTest':
        $ret = kasse_print::BonPrinterTest();
        echo  useful::array2xml($ret);
        break;
    case 'Datensicherung':
        $ret = kasse::Datensicherung();
        echo  useful::array2xml($ret);
        break;
    case 'LadeVorgaenge':
        $ret = kasse::draw_VorgaengeList();
        echo  useful::array2xml($ret);
        break;
    case 'PrintBonKopie':
        $ret = kasse_dialog::PrintBonKopie();
        echo  useful::array2xml($ret);
        break;
    case 'Synch':

        if(is_file('config/config.accdb.php'))
        {
            require_once('config/config.accdb.php');
            // controller/kasse/
        }


        $ret = synch::synchronisiere_zjournal();
        echo  useful::array2xml($ret);
        break;
    default:
        $ret['message'] = ' do is not set or accepted  ';
        echo  useful::array2xml($ret);
}
?>