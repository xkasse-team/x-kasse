<?php
class kasse_dialog
{



    public function doAbschlussVorbereiten()
    {
        // Prüfen, ob bargegebenSumme >= VorgangSumme ist
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Vorgang 0 nicht gefunden';
        $vorgang = kasse_dialog::BerechneVorgangMwStGruppiert(@$_REQUEST['vorgangID'],'');
        $ret['message'] = print_r($vorgang,true);
        return $ret;


    }

    public function PrintBonKopie()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Vorgang 0 nicht gefunden';

        $Vorgang = kasse::getVorgang($_REQUEST['VorgangID']);
        if($Vorgang==false) return $ret;


        $print = kasse_print::PrintBon($Vorgang['id']);

        if($print['success']==1)
        {

            $ret['success'] = 1;


            $ret['message'] = 'Bon gedruckt';
            return $ret;
        }
        else
        {
            $ret['message'] = print_r($print,true);
            return $ret;
        }
    }

    public function doAbschlussVorgang()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Vorgang 0 nicht gefunden '.BONPRINTER_USE;


        // !!! $_REQUEST['VorgangID'] bezieht sich auf den aktuell in der Session temporären Vorgang !!

        if(intval($_REQUEST['VorgangID'])==0)
        {
            return $ret;
        }



        $vorgang = kasse::getVorgang(intval($_REQUEST['VorgangID']),'');
        $VorgangPositionenCheck = kasse::getVorgangTmp($vorgang['id']);

        $vorgangSummen = kasse_dialog::BerechneVorgangMwStGruppiert($vorgang['id'],'');


        // Nur bei BAR die ControlSummer prüfen
        if($_REQUEST['ZahlungArt']=='BAR')
        {
            $control['ControlSummeBar'] = floatval($_REQUEST['ControlSummeBar']);
            $control['ControlSummeBrutto'] = $vorgangSummen['TotalBrutto'];


            if(
                $control['ControlSummeBar'] < $vorgangSummen['TotalBrutto']
            )
            {
                $ret['message'] = 'ControlSummeBrutto: '.$control['ControlSummeBar'].' != '.$vorgangSummen['TotalBrutto'];
                return $ret;
            }

        }
        else
        {
            $control['ControlSummeBar'] = $vorgangSummen['TotalBrutto'];
            $control['ControlSummeBrutto'] = $vorgangSummen['TotalBrutto'];
        }





        if(!is_array(@$VorgangPositionenCheck['Journal']) || count(@$VorgangPositionenCheck['Journal'])==0)
        {
            $ret['message'] = 'Keine Positionen vorhanden - Kein Abschluss möglich';
            return $ret;
        }

        if($_SESSION['kasse']['BenutzerKurz'] != $vorgang['BenutzerKurz'])
        {
            $ret['message'] = 'Vorgang gehört: '.$vorgang['BenutzerKurz'];
            return $ret;
        }
        if(intval($vorgang['Abschluss'])==1 || intval($vorgang['BonGedruckt'])==1)
        {
            $ret['message'] = 'VorgangID bereits abgeschlossen';
            return $ret;
        }
        if(!in_array($_REQUEST['VorgangArt'],VORGANG_ARTEN))
        {
            $ret['message'] = 'ZielBeleg ungültig';
            return $ret;
        }


        // negativer Abschluss Check
        /*
        $check = kasse_dialog::BerechneVorgangMwStGruppiert($vorgang['id'],'');
        if($check['TotalBrutto']<=-100)
        {
            $ret['message'] = 'Negativer Summenwert nicht zulässig';
            return $ret;
        }
        */

        if($_REQUEST['VorgangArt']=='STORNO')
        {
            $sql = 'UPDATE kasse_vorgaenge SET
            UpdateDatetime = "'.date("Y-m-d H:i:s").'",
            Abschluss=1,
            AbschlussDatetime="'.date("Y-m-d H:i:s").'",
            VorgangArt="STORNO",
            ZahlungsArt="XX",
            ControlSummeBrutto="'.$control['ControlSummeBrutto'].'",
            ControlSummeBar="'.$control['ControlSummeBar'].'",
            ControlECBeleg="'.strip_tags($_REQUEST['ControlECBeleg']).'",

            ControlBemerkung="'.strip_tags($_REQUEST['ControlBemerkung']).'"

            WHERE id='.$vorgang['id'];

            $updated = DB::update($sql);
        }
        if($_REQUEST['VorgangArt']=='VERKAUF')
        {
            // nur wenn kein storno:
            if(kasse::isZahlungsart($_REQUEST['ZahlungArt'])==false)
            {
                $ret['message'] = 'Zahlungsart ungültig: '.$_REQUEST['ZahlungArt'];
                return $ret;
            }
            $sql = 'UPDATE kasse_vorgaenge SET
            UpdateDatetime = "'.date("Y-m-d H:i:s").'",
            Abschluss=1,
            AbschlussDatetime="'.date("Y-m-d H:i:s").'",
            VorgangArt="VERKAUF",
            ZahlungsArt="'.$_REQUEST['ZahlungArt'].'",
            ControlSummeBrutto="'.$control['ControlSummeBrutto'].'",
            ControlSummeBar="'.$control['ControlSummeBar'].'",
            ControlECBeleg="'.strip_tags($_REQUEST['ControlECBeleg']).'"

            WHERE id='.$vorgang['id'];

            $updated = DB::update($sql);
        }


        // ab hier kommt der Vorgang in den Z-Bereich
        // eine eindeutige ID ist nach dem INSERt vorhanden
        // insert into kasse_zvorgaenge
        // insert into kasse_zjournal

        // Vorgang umziehen
        // Niemals dies verschieben:
        // Der Zustand des Tmp Vorgangs hat sich in den obigen Zeilen verändert und muss in diesem Zusatand gezogen werden:
        $VorgangTmp = kasse::getVorgangTmp($vorgang['id']);

        $sql_a = array();
        $sql_b = array();
        foreach($VorgangTmp as $key => $value)
        {
            if($key!='Journal')
            {
                $sql_a[] = $key;
                $sql_b[] = $value;
            }
        }
        $sql = 'INSERT INTO kasse_zvorgaenge
        ('.implode(',',$sql_a).')
        VALUES
        ("'.implode('","',$sql_b).'")
        ';
        $insertVorgangID = DB::insert($sql);

        if(intval($insertVorgangID)==0)
        {
            $ret['success'] = 0;
            $ret['message'] = 'Fehler beim Ablegen des Vorgangs in der Z-Tabelle - Datenbankkonflikt';
            return $ret;
        }

        foreach($VorgangTmp['Journal'] as $p)
        {
            // !!!
            $p['VorgangID'] = $insertVorgangID;
            $p['InsertDatetime'] = date("Y-m-d H:i:s");


            $sql_a = array();
            $sql_b = array();

            foreach($p as $key => $value)
            {
                $sql_a[] = $key;
                $sql_b[] = $value;
            }
            $sql = 'INSERT INTO kasse_zjournal
            ('.implode(',',$sql_a).')
            VALUES
            ("'.implode('","',$sql_b).'")
            ';
            $insertJournalID = DB::insert($sql);
        }


        // alten Vorgang Inhalt löschen:
        $sql = 'DELETE FROM kasse_journal WHERE VorgangID='.$vorgang['id'];
        $done = DB::delete($sql);
        $sql = 'DELETE FROM kasse_vorgaenge WHERE id='.$vorgang['id'];
        $done = DB::delete($sql);


        // Vorgang neu aus der Z Tabelle aufrufen:
        $zVorgang = kasse::getVorgang($insertVorgangID,'z');

        if(!in_array($zVorgang['VorgangArt'],VORGANG_ARTEN))
        {
            $ret['message'] = 'Error: #99: '.$zVorgang['VorgangArt'];
            return $ret;
        }

        if($zVorgang==false)
        {
            $ret['message'] = 'Problem beim Abschluss des Vorgangs: '.$sql;
            return $ret;
        }
        else
        {
            $print = kasse_print::PrintBon($zVorgang['id'],BONPRINTER_USE);

            if($print['success']==1)
            {
                $sql = 'UPDATE kasse_zvorgaenge SET
                BonGedruckt=1,
                BonGedrucktDatetime	 = "'.date("Y-m-d H:i:s").'"
                WHERE id='.$zVorgang['id'];

                $updated = DB::update($sql);

                $ret['success'] = 1;

                $ret['Wechselgeld'] = kasse::euro($control['ControlSummeBar'] - $vorgangSummen['TotalBrutto']);

                $ret['message'] = 'Bon gedruckt';
                return $ret;
            }
            else
            {
                $ret['message'] = 'Problem beim Drucken! '.BONPRINTER_USE;
                return $ret;
            }
        }



        return $ret;

    }
    public function getLetztenOffenenVorgang()
    {
        if(intval(@$_SESSION['kasse']['user_id'])==0) return false;

        $sql = 'select * from kasse_vorgaenge where Abschluss=0 AND BenutzerID='.$_SESSION['kasse']['user_id'];
        $v = DB::fetcharray($sql);
        if(count($v)==0 || $v==false)
        {

            // Vorgang anlegen
            $kassye_sys = kasse::kasse_signatur();

            $sql = 'insert into kasse_vorgaenge
            (
                BenutzerID,
                BenutzerKurz,
                InsertDatetime,
                Abschluss,
                VorgangArt,
                KdNr,
                SystemInfo

            )
            values
            (
                "'.$_SESSION['kasse']['user_id'].'",
                "'.$_SESSION['kasse']['BenutzerKurz'].'",
                "'.date("Y-m-d H:i:s").'",
                "0",
                "Offener Vorgang",
                "0",
                 "'.$kassye_sys['SystemInfo'].'"
            )

            ';

            $insertid = DB::insert($sql);

            $sql = 'select * from kasse_vorgaenge where Abschluss=0 AND BenutzerID='.$_SESSION['kasse']['user_id'];
            $v = DB::fetcharray($sql);
            return $v[0];

        }
        else
        {
            return $v[0];
        }
    }
    public function getHinzuForm()
    {
        // zeigt entweder das gefundene Produkt oder eine Auswahl an Produkten die in Volltextsuche gefunden wurden



        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Produkt nicht gefunden';

        $find_product = ArtikelStammDB::getArtikel('ArtNr',@$_REQUEST['ArtNr'],0);

        if($find_product==false)
        {


            $search = ArtikelStammDB::SearchProduct(@$_REQUEST['ArtNr']);
            if($search==false)
            {
                return $ret;
            }
            else
            {

                if(!is_array($search))
                {
                    $ret['FoundProductsForm'] = 'o Elements';
                    return $ret;
                }

                $ret['FoundProductsForm'] = '
                <h2>Suchergebnis:</h2>
                <ul class="FoundProductsNested">
                ';
                foreach($search as $warengruppe)
                {
                    $ret['FoundProductsForm'].= '<li><h1>'.$warengruppe['Warengruppe'].' ('.count($warengruppe['products']).')</h1>';
                    $ret['FoundProductsForm'].= '<ul>';
                    foreach($warengruppe['products'] as $p)
                    {
                        $p['ProductImageUrl'] = kasse_dialog::getProductImageurl($p['ArtNr']);
                        $p['vk_preise'] = ArtikelStammDB::getArtikelPreise($p['ArtNr'],0);
                        $p['vk_preise_html'] = '<table class="PreiseTable">';
                        if(is_array($p['vk_preise']))
                        {
                            foreach($p['vk_preise'] as $key=>$pp)
                            {
                                $p['vk_preise_html'].= '
                                <tr>
                                <td>'.$pp['ehvk'].$p['Mass'].'</td>
                                <td><span class="Euro">'.CURRENCY_SYM.'</span>'.kasse::euro($pp['P']).'</td>
                                <td>
                                    <button
                                    class="ButtonHinzu"
                                    id="Hinzu-'.$key.'"

                                    data-artnr="'.$p['ArtNr'].'"
                                    data-p="'.$pp['P'].'"
                                    data-ehvk="'.$pp['ehvk'].'"
                                    data-mass="'.$p['Mass'].'"
                                    >
                                    Hinzu
                                    </button></td>
                                </tr>';
                            }
                        }

                        $p['vk_preise_html'].= '</table>';

                        $ret['FoundProductsForm'].= useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/ProductPreviewSearchItem.html',$p,0,array());
                    }
                    $ret['FoundProductsForm'].= '</ul>';
                    $ret['FoundProductsForm'].= '</li>';
                }

                $ret['FoundProductsForm'].= '
                </ul>';

                if(count($search)>1)
                {
                    $ret['FoundProductsForm'].= '
                       <script>
                           $("ul.FoundProductsNested>li>ul").fadeOut();

                           $("ul.FoundProductsNested>li>h1").click(function()
                           {
                               $(this).parent("li").children("ul").toggle();
                           });

                       </script>
                       ';
                }


                return $ret;
            }



        }


        $find_product['vk_preise_debug'] = print_r($find_product['vk_preise'],true);


        $find_product['HinzuForm'] = '<table class="PreiseTable">';

        if(!is_array($find_product['vk_preise'])) return 'Keine Preise gefunden';

        // Staffelpreise oder versch. Abpackmengen?
        $check = 0;
        foreach($find_product['vk_preise'] as $key=>$p)
        {
            $check = $check + $p['ab'];
        }
        if($check != count($find_product['vk_preise']))
        {
            // die summe der "Ab" Werte entspricht nicht der Anzahl der preise, also ist dies ein Staffelpreis Artikel
            foreach($find_product['vk_preise'] as $key=>$p)
            {
                $find_product['HinzuForm'].= '
                <tr>
                <td>ab '.$p['ab'].'</td>
                <td class="align-right"><span class="Euro">'.CURRENCY_SYM.'</span>'.kasse::euro($p['P']).'</td>
                <td>
                <button
                    class="ButtonHinzu"
                    id="Hinzu-'.$key.'"

                    data-artnr="'.$p['ArtNr'].'"
                    data-p="'.$p['P'].'"
                    data-ehvk="'.$p['ehvk'].'"
                    data-mass="'.$find_product['Mass'].'"
                    >
                    Hinzu
                    </button>
                    </td>
                </tr>';
            }
        }
        else
        {
            foreach($find_product['vk_preise'] as $key=>$p)
            {
                $find_product['HinzuForm'].= '
                <tr>
                <td>'.$p['ehvk'].$find_product['Mass'].'</td>
                <td class="align-right"><span class="Euro">'.CURRENCY_SYM.'</span>'.kasse::euro($p['P']).'</td>
                <td>

                                <button
                    class="ButtonHinzu"
                    id="Hinzu-'.$key.'"

                    data-artnr="'.$p['ArtNr'].'"
                    data-p="'.$p['P'].'"
                    data-ehvk="'.$p['ehvk'].'"
                    data-mass="'.$find_product['Mass'].'"
                    >
                    Hinzu
                    </button>


                </td>
                </tr>';
            }
        }




        $find_product['ProductImageUrl'] = kasse_dialog::getProductImageurl($find_product['ArtNr']);


        $find_product['HinzuForm'].='</table>';

        if($find_product==false) return $ret;

        $ret['HinzuForm'] = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/ProductPreview.html',$find_product,0,array());

        $ret['message'] = 'Produkt gefunden';
        $ret['success'] = 1;

        return $ret;

    }
    function getProductImageurl($ArtNr)
    {
        $find_product= array();



        if(is_file(KASSEROOT.PRODUCT_IMAGES_BE.strtolower($ArtNr).'.jpg'))
        {
           $find_product['ProductImageUrl'] = PRODUCT_IMAGES_FE.strtolower($ArtNr.'.jpg');
        }
        else
        {
           $find_product['ProductImageUrl'] = PRODUCT_IMAGES_FE.'1.jpg';
           //$find_product['ProductImageUrl'] = PRODUCT_IMAGES_BE.strtolower($ArtNr).'.jpg';
           //$find_product['ProductImageUrl'] = PRODUCT_IMAGES_FE.strtolower('1.jpg');
        }

        return $find_product['ProductImageUrl'];
    }
    public function scan()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Es wurde gescanned: '.$_REQUEST['barcode'];


        $p = ArtikelStammDB::getArtikelPreisbyScan($_REQUEST['barcode']);

        //$product = ArtikelStammDB::getArtikel('ArtNr',$p['ArtNr'],0);

        if($p==false)
        {
            $ret['message'] = 'Produkt/Preis wurde nicht gefunden ';
            return $ret;
        }




        //Für ein "Hinzu" notwendigen Werte:

        $ret['ArtNr'] = $p['ArtNr'];
        $ret['ArtikelBezeichnung'] = $p['ArtikelBezeichnung'];
        //$ret['Anzahl'] = $p['ArtNr'];
        $ret['EpBrutto'] = $p['P'];
        $ret['CUR'] = CURRENCY;
        //$ret['Rabatt'] = $p['ArtNr'];
        //$ret['MwstProzent'] = $p['ArtNr'];
        //$ret['InsertDatetime'] = $p['ArtNr'];
        //$ret['InsertByBenutzerKurz'] = $p['ArtNr'];
        $ret['Menge'] = $p['ehvk'];
        $ret['Mengeneinheit'] = $p['Mengeneinheit'];

        //$ret['message'] = print_r($p,true).print_r(,true);

        //$ret['message'] = print_r($_REQUEST,true);

        //$ret['Anzahl'] = $p['P'];


        $ret['success'] = 1;

        return $ret;
    }
    public function GetKunde($kundennummer=0)
    {
       $kunde = ArtikelStammDB::getKunde(intval($kundennummer));

        return $kunde;
    }
    public function doSearchKunden()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error SearchKd '.print_r($_REQUEST,true);


        $ret['KundenListe'] = 'Keine Kunden gefunden';
        
        
        $kunden = ArtikelStammDB::SearchKunden($_REQUEST['SucheKunden']);
        
        if(count($kunden)==0 || $kunden==false)
        {
            return $ret;
        }
        $ret['KundenListe'] = '
                <table class="KundenListe tablesort">
                <thead>
                <tr>
                        <th>KdNr</th>
                        <th>Kunde Name</th>
                        <th>Plz, Ort</th>

                </tr>
                </thead>
                <tbody>
                ';
        foreach($kunden as $kunde)
        {
            $ret['KundenListe'].= useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/KundensucheItem.html',$kunde,0,array());

        }
        $ret['KundenListe'].='</tbody></table>';
        
        $ret['message'] = print_r($kunden,true);
        return $ret;
    }
    public function doSelectKunden()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error SelectKunden '.print_r($_REQUEST,true);

        // Todo
        // 1) Kein hinzu wenn Vorgang abgeschlossen ist
        // 2) VorgangID muss in jedem Falle übergeben werden

        if(intval($_REQUEST['VorgangID'])==0)
        {
            $ret['message'] = 'VorgangID ist 0';
            return $ret;
        }
        if(intval($_REQUEST['kundennummer'])==0)
        {
            $ret['message'] = 'kundennummer ist 0';
            return $ret;
        }

        $kunde = kasse_dialog::getKunde(intval($_REQUEST['kundennummer']));
        if($kunde==false) return $ret;

        $vorgang = kasse::getVorgang(intval($_REQUEST['VorgangID']),'');

        if($_SESSION['kasse']['BenutzerKurz'] != $vorgang['BenutzerKurz'])
        {
            $ret['message'] = 'Vorgang gehört: '.$vorgang['BenutzerKurz'];
            return $ret;
        }

        if(intval($vorgang['Abschluss'])==1 || intval($vorgang['BonGedruckt'])==1)
        {
            $ret['message'] = 'VorgangID bereits abgeschlossen';
            return $ret;
        }

        $sql = 'UPDATE kasse_vorgaenge set
        KdNr='.$kunde['kundennummer'].',

        R_Anrede="'.$kunde['Anrede'].'",
        R_Vorname="'.$kunde['Vorname'].'",
        R_Name="'.$kunde['Name'].'",
        R_Ansprechperson="'.$kunde['Ansprechperson'].'",
        R_Strasse="'.$kunde['Strasse'].'",
        R_PLZ="'.$kunde['PLZ'].'",
        R_Ort="'.$kunde['Ort'].'",
        UpdateDatetime="'.date("Y-m-d H:i:s").'"
        WHERE BenutzerKurz="'.$_SESSION['kasse']['BenutzerKurz'].'" AND id='.$vorgang['id'];

        $updated=DB::update($sql);

        if($updated==1)
        {
            $ret['success'] = 1;
            return $ret;
        }
        else
        {
            $ret['message'] = print_r($updated,true);
            return $ret;
        }


    }
    public function doShowKunde()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error ShowtKunde '.print_r($_REQUEST,true);

        return $ret;
    }
    public function doStornoUndo()
    {
        $z='';

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error StornoUndo '.print_r($_REQUEST,true);
        if(intval($_REQUEST['VorgangID'])==0)
        {
            $ret['message'] = 'VorgangID ist 0';
            return $ret;
        }
        $vorgang = kasse::getVorgang(intval($_REQUEST['VorgangID']),'');

        if($_SESSION['kasse']['BenutzerKurz'] != $vorgang['BenutzerKurz'])
        {
            $ret['message'] = 'Vorgang gehört: '.$vorgang['BenutzerKurz'];
            return $ret;
        }
        if(intval($vorgang['Abschluss'])==1 || intval($vorgang['BonGedruckt'])==1)
        {
            $ret['message'] = 'VorgangID bereits abgeschlossen';
            return $ret;
        }

        $request = kasse_dialog::getLetzteHinzuPosition($vorgang['id']);

        if($request['EpBrutto'] <= 0)
        {
            $ret['message'] = 'Betrag der Position war negativ oder 0';
            return $ret;
        }
        $request['InsertDatetime'] = date("Y-m-d H:i:s");
        $request['BelegInfo'] =JOURNAL_UNDO;
        $request['EpBrutto'] = $request['EpBrutto'] * -1;
        $request['zSummeBrutto'] = $request['zSummeBrutto'] * -1;
        $request['zSummeNetto'] = $request['zSummeNetto'] * -1;
        $request['zSummeMwSt'] = $request['zSummeMwSt'] * -1;
        unset($request['ID']);

        $i=0;
        $keys='';
        foreach($request as $key=>$value)
        {
            $keys.=$key;
            if($i < count($request)-1)
            {
                $keys.=',';
            }
            $i++;
        }

        $ret['sql'] = 'INSERT INTO kasse_'.$z.'journal ('.$keys.')';
        $ret['sql'].= ' VALUES ("'.@implode('","',$request).'")';

        //$ret['message'] = $ret['sql'];

        $inserted = DB::insert($ret['sql']);


        if(intval($inserted)>0)
        {
            $ret['success'] = 1;
        }

        //$ret['message'] = print_r($request,true);

        return $ret;
    }
    public function doHinzu()
    {
        $z='';
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error Hinzu '.print_r($_REQUEST,true);

        // Todo
        // 1) Kein hinzu wenn Vorgang abgeschlossen ist
        // 2) VorgangID muss in jedem Falle übergeben werden

        if(intval($_REQUEST['VorgangID'])==0)
        {
            $ret['message'] = 'VorgangID ist 0';
            return $ret;
        }
        if(intval(ARTNR_DEFAULT)==0)
        {
            $ret['message'] = ARTNR_DEFAULT.' ist 0';
            return $ret;
        }

        $vorgang = kasse::getVorgang(intval($_REQUEST['VorgangID']),'');

        if($_SESSION['kasse']['BenutzerKurz'] != $vorgang['BenutzerKurz'])
        {
            $ret['message'] = 'Vorgang gehört: '.$vorgang['BenutzerKurz'];
            return $ret;
        }

        if(intval($vorgang['Abschluss'])==1 || intval($vorgang['BonGedruckt'])==1)
        {
            $ret['message'] = 'VorgangID bereits abgeschlossen';
            return $ret;
        }

        if(empty($_REQUEST['ArtNr']))
        {
            $ret['message'] = 'ArtNr ungültig';
            return $ret;
        }

        //********************************************************** BelegInfo
        if(!in_array(strip_tags(trim(@$_REQUEST['BelegInfo'])),BELEGINFO_ARTEN))
        {
            $_REQUEST['BelegInfo'] ="";
        }


        // wenn Sammler-Artikel über Warengrupüpe gebucht wird:
        if(@$_REQUEST['ArtNr'] == ARTNR_DEFAULT)
        {
            // Die übergebene Warengrupen ID soll stimmen:
            // if(warengruppenid
            $warengruppen = kasse::GetWarengruppen();
            if(!isset($warengruppen[
                                intval($_REQUEST['WarengruppenId'])
                                ]))
            {
                $ret['message'] = 'Warengruppe #'.intval($_REQUEST['WarengruppenId']).' existiert nicht';
                return $ret;
            }

            if($_REQUEST['Prefix']=='%')
            {
                if((floatval($_REQUEST['P'])*100) >10)
                {
                    $ret['message'] = 'Rabatt max 10% ';
                    return $ret;
                }
                if((floatval($_REQUEST['P'])*100) < 0)
                {
                    $ret['message'] = 'Rabatt min 1% ';
                    return $ret;
                }


                // rabatt % auf alle aktuelle Positionen des Vorgangs setzen:

                $NewRabatt = floatval($_REQUEST['P'])*100;

                $sql = 'UPDATE kasse_journal set
                        Rabatt='.$NewRabatt.',
                        zSummeBrutto = ROUND((Anzahl * EpBrutto) / 100 * (100-'.$NewRabatt.'),2),
                        zSummeNetto = ROUND((zSummeBrutto / (100+MwstProzent)) * 100 , 2),
                        zSummeMwSt = ROUND(zSummeBrutto - zSummeNetto,2)
                        WHERE VorgangID='.$vorgang['id'];

                        $updated=DB::update($sql);


                            $ret['success'] = 1;
                            return $ret;


                /*
                $request['vorgangID'] = $vorgang['id'];
                $request['BelegInfo'] = strip_tags($_REQUEST['BelegInfo']);
                $request['ArtNr'] = ARTNR_DEFAULT;
                $request['ArtikelBezeichnung'] = addslashes($warengruppen[intval($_REQUEST['WarengruppenId'])]['Warengruppe']);
                $request['Anzahl'] = floatval($_REQUEST['Anzahl']);
                $request['Menge'] = floatval($_REQUEST['Menge']);
                $request['Mengeneinheit'] = strip_tags($_REQUEST['MengenEinheit']);
                $request['WarengruppenId'] = intval($_REQUEST['WarengruppenId']);
                $request['EpBrutto'] = (floatval($_REQUEST['P'])*100).$_REQUEST['Prefix'];
                $request['CUR'] = CURRENCY;
                $request['Rabatt'] = 0;
                $request['MwstProzent'] = $warengruppen[intval($_REQUEST['WarengruppenId'])]['MwStSatz'];
                $request['InsertDatetime'] = date("Y-m-d H:i:s");
                $request['InsertByBenutzerKurz'] = $_SESSION['kasse']['BenutzerKurz'];
                */
            }
            else
            {
                $request['vorgangID'] = $vorgang['id'];
                $request['BelegInfo'] = strip_tags($_REQUEST['BelegInfo']);
                $request['ArtNr'] = ARTNR_DEFAULT;
                $request['ArtikelBezeichnung'] = addslashes($warengruppen[intval($_REQUEST['WarengruppenId'])]['Warengruppe']);
                $request['Anzahl'] = floatval($_REQUEST['Anzahl']);
                $request['Menge'] = floatval($_REQUEST['Menge']);
                $request['Mengeneinheit'] = strip_tags($_REQUEST['MengenEinheit']);
                $request['WarengruppenId'] = intval($_REQUEST['WarengruppenId']);
                $request['Rabatt'] = 0;
                $request['MwstProzent'] = $warengruppen[intval($_REQUEST['WarengruppenId'])]['MwStSatz'];

                $request['EpBrutto'] = strip_tags($_REQUEST['Prefix']).floatval($_REQUEST['P']);
                $request['zSummeBrutto'] = ROUND(($request['Anzahl'] * $request['EpBrutto']) / 100 * (100-$request['Rabatt']),2);
                $request['zSummeNetto'] = ROUND(($request['zSummeBrutto'] / (100+$request['MwstProzent'])) * 100 , 2);
                $request['zSummeMwSt'] = ROUND($request['zSummeBrutto'] - $request['zSummeNetto'],2);

                $request['CUR'] = CURRENCY;
                $request['InsertDatetime'] = date("Y-m-d H:i:s");
                $request['InsertByBenutzerKurz'] = $_SESSION['kasse']['BenutzerKurz'];
            }







            $ret['message'] = print_r($request,true);
            $ret['debug'] = print_r($request,true);



        }

        if(@$_REQUEST['ArtNr'] != ARTNR_DEFAULT)
        {
            $artikel = ArtikelStammDB::getArtikel('ArtNr',$_REQUEST['ArtNr'],0);

            if($artikel==false )
            {
               $ret['message'] = 'ArtNr nicht gefunden '.print_r($artikel,true);

               return $ret;
            }

            // Eine Position wird grundsätzlich zum aktuellen Vorgang des Bedieners gebucht:
            $request['vorgangID'] = $vorgang['id'];
            $request['BelegInfo'] = strip_tags($_REQUEST['BelegInfo']);
            $request['ArtNr'] = $artikel['ArtNr'];
            $request['ArtikelBezeichnung'] = addslashes($artikel['ArtikelBezeichnung'].' '.$artikel['Artikelgruppe']);
            $request['Anzahl'] = floatval($_REQUEST['Anzahl']);
            $request['Menge'] = floatval($_REQUEST['Menge']);
            $request['Mengeneinheit'] = strip_tags($_REQUEST['MengenEinheit']);
            $request['WarengruppenId'] = intval($artikel['kasse_wgid']);
            $request['Rabatt'] = 0;
            $request['MwstProzent'] = $artikel['MwStSatz'];

            $request['EpBrutto'] = strip_tags($_REQUEST['Prefix']).floatval($_REQUEST['P']);
            $request['zSummeBrutto'] = ROUND(($request['Anzahl'] * $request['EpBrutto']) / 100 * (100-$request['Rabatt']),2);
            $request['zSummeNetto'] = ROUND(($request['zSummeBrutto'] / (100+$request['MwstProzent'])) * 100 , 2);
            $request['zSummeMwSt'] = ROUND($request['zSummeBrutto'] - $request['zSummeNetto'],2);


            $request['CUR'] = CURRENCY;


            $request['InsertDatetime'] = date("Y-m-d H:i:s");
            $request['InsertByBenutzerKurz'] = $_SESSION['kasse']['BenutzerKurz'];
        }



        $ret['message'] = print_r($request,true);
        $ret['debug'] = print_r($request,true);

        $i=0;
        $keys='';
        foreach($request as $key=>$value)
        {
            $keys.=$key;
            if($i < count($request)-1)
            {
                $keys.=',';
            }
            $i++;
        }

        $ret['sql'] = 'INSERT INTO kasse_journal ('.$keys.')';
        $ret['sql'].= ' VALUES ("'.@implode('","',$request).'")';

        //$ret['message'] = $ret['sql'];

        $inserted = DB::insert($ret['sql']);


        if(intval($inserted)>0)
        {
            $ret['success'] = 1;
        }

        return $ret;


    }
    public function getLetzteHinzuPosition($VorgangID=0)
    {
        $z='';
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error Vorgang berechnen';

        $sql ='SELECT * FROM kasse_'.$z.'journal WHERE VorgangID='.$VorgangID.'
        ORDER BY ID DESC
        LIMIT 1
        ';
        $pos = DB::fetcharray($sql);

        if($pos==false)
        {
            return false;
        }
        else
        {
            return $pos[0];
        }



    }
    public function doBerechneVorgang($z='')
    {

        // reagiert auf REQUEST [do] == BerechneVorgang
        // liefert Anzeigeelemente in Frontend Kasse
        // liefert AnzeigeElemente für Bon Druck

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Start Vorgang berechnen leere Meldung';


        // !!!! $_SESSION['kasse']['VorgangID']


        $cart = array();
        $cart[] ='<table class="JournalVorschau">
                    <thead>
                    <tr>
                        <th>ANZ</th>
                        <th>ME</th>
                        <th>ArtNr</th>
                        <th class="ArtikelBezeichnerInline">Artikel</th>
                        <th>EP</th>
                        <th>R</th>
                        <th>M</th>
                        <th>SUM</th>
                    </tr>
                    </thead>
                    <tbody>
                ';


                /*
                        $cart = array();
                        $v = kasse_dialog::BerechneVorgang($_SESSION['kasse']['VorgangID']);
                        $cart[] ='<table><thead><tr>
                            <th>ANZ</th>
                            <th>ME</th>
                            <th>ArtNr</th>
                            <th>Bez</th>
                            <th>M</th>
                            <th>EP</th>
                            <th>R</th>
                            <th>SUM</th>
                        </tr>
                        </thead>
                        <tbody>
                        ';
                        foreach($v as $p)
                        {
                            $cart[] = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/CartItem.html',$p,0,array());
                        }
                        $cart[] = '</tbody></table>';
                        $ret['message'] = @implode("\n",$cart);
                */

        $vorgang = kasse::getVorgang($_SESSION['kasse']['VorgangID'],$z);

        $ret['KundenAdresseVorschau'] = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/KundeAnzeigenDetail.html',$vorgang,0,array());

        $vv = kasse_dialog::BerechneVorgangGruppiert($_SESSION['kasse']['VorgangID'],'DESC',$z);


        if(count($vv)==0 || $vv==false)
        {
            return $ret;
        }



        if(is_array($vv))
        {
            foreach($vv as $p)
            {
                if($p['zSummeBrutto']<0)
                {
                    $p['plusminus'] = 'minus';
                }
                else
                {
                    $p['plusminus'] = 'plus';
                }

                $cart[] = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/CartItem.html',$p,0,array());
            }
        }


        $cart[] = '</tbody></table>';

        $ret['Journal'] = @implode("\n",$cart);

        $vvv = kasse_dialog::BerechneVorgangMwStGruppiert($_SESSION['kasse']['VorgangID'],$z);

        $ret['JournalFooter'] = '<table id="JournalFooterSumTable" data-summebrutto="'.$vvv['TotalBrutto'].'" width="100%">
        <tr class="SmallFonts">
        <td>MwSt</td>
        <td>Netto</td>
        <td>MwSt</td>
        <td>Brutto</td>
        </tr>';
        if(is_array($vvv['JournalFooter'] ))
        {
            foreach($vvv['JournalFooter'] as $sum)
            {
                $ret['JournalFooter'].= '<tr class="SmallFonts">
                <td>'.$sum['MwstProzent'].'%</td>
                <td>'.CURRENCY_SYM.kasse::euro($sum['SUMME_NET']).'</td>
                <td>'.CURRENCY_SYM.kasse::euro($sum['MwStBetrag']).'</td>
                <td>'.CURRENCY_SYM.kasse::euro($sum['SUMME']).'</td>
                </tr>';
            }
        }


        $ret['JournalFooter'].='<tr><td colspan="4">'.CURRENCY_SYM.$vvv['TotalBrutto'].'</td></tr>';
        $ret['JournalFooter'].='</table>';


        //$ret['JournalFooter'] = $vvv['TotalBrutto'];





        //$ret['message'] = print_r($v,true);
        return $ret;
    }
    public function BerechneVorgang($id,$z='z')
    {
        $v = kasse::getVorgang($id,$z);

        $sql = 'select *
         from kasse_'.$z.'journal
        where VorgangID = '.$id.'
        order by ID DESC ';

        $list = DB::fetcharray($sql);
        $i=0;
        foreach($list as $l)
        {
            $new[$i] = $l;
            $new[$i]['EpBrutto_format'] = kasse::euro($l['EpBrutto']);
            $new[$i]['zSummeBrutto_format'] = kasse::euro($l['zSummeBrutto']);
            $new[$i]['ArtikelBezeichnung_cut'] = $l['ArtikelBezeichnung'];


            if(floatval($l['Rabatt'])>0)
            {
                $new[$i]['Rabatt_format'] = '-Rabatt '.$l['Rabatt'].'%';
            }
            else
            {
                $new[$i]['Rabatt_format'] = '';
            }


            $i++;
        }

        return $new;
    }
    public function BerechneVorgangGruppiert($id,$Orderby='ASC',$z='z')
    {

        // Diese Funktion berechnet ein Array für
        // Bon Druck
        // Vorschau in Kasse

        // Bei Vorschau in kasse neueste nach oben:
        if($Orderby=='GROUPED')
        {
            $Orderby= 'Warengruppe ASC';
        }
        else
        {
            $Orderby='Last ASC';
        }



        $v = kasse::getVorgang($id,$z);

        $sql = 'select
        kasse_warengruppen.Warengruppe,
        kasse_'.$z.'journal.WarengruppenId,
        max(kasse_'.$z.'journal.ID) AS Last,
        kasse_'.$z.'journal.BelegInfo,
        Sum(kasse_'.$z.'journal.Anzahl) AS Anzahl,
        kasse_'.$z.'journal.ArtNr,
        kasse_'.$z.'journal.ArtikelBezeichnung,
        kasse_'.$z.'journal.EpBrutto,
        kasse_'.$z.'journal.Rabatt,

        SUM(kasse_'.$z.'journal.zSummeBrutto) AS zSummeBrutto,
        SUM(kasse_'.$z.'journal.zSummeNetto) AS zSummeNetto,
        SUM(kasse_'.$z.'journal.zSummeMwSt) AS zSummeMwSt,

        kasse_'.$z.'journal.Menge,
        kasse_'.$z.'journal.Mengeneinheit,
        kasse_'.$z.'journal.MwstProzent,
        kasse_'.$z.'journal.CUR

        FROM kasse_'.$z.'journal
        LEFT JOIN kasse_warengruppen ON kasse_warengruppen.id = kasse_'.$z.'journal.Warengruppenid
        WHERE kasse_'.$z.'journal.VorgangID = '.$id.'

 GROUP BY
         kasse_warengruppen.Warengruppe,
         kasse_'.$z.'journal.WarengruppenId,
         kasse_'.$z.'journal.ArtNr,
         kasse_'.$z.'journal.BelegInfo,
         kasse_'.$z.'journal.ArtikelBezeichnung,
         kasse_'.$z.'journal.EpBrutto,
         kasse_'.$z.'journal.Rabatt,

         kasse_'.$z.'journal.Menge,
         kasse_'.$z.'journal.Mengeneinheit,
         kasse_'.$z.'journal.MwstProzent,
         kasse_'.$z.'journal.CUR

        order by '.$Orderby;

        $list = DB::fetcharray($sql);
        $i=0;
        if($list==false) return false;
        foreach($list as $l)
        {
            $new[$i] = $l;
            $new[$i]['EpBrutto_format'] = kasse::euro($l['EpBrutto']);
            $new[$i]['zSummeBrutto_format'] = kasse::euro($l['zSummeBrutto']);
            $new[$i]['zSummeNetto_format'] = kasse::euro($l['zSummeNetto']);
            $new[$i]['zSummeMwSt_format'] = kasse::euro($l['zSummeMwSt']);

            $new[$i]['ArtikelBezeichnung_cut'] = $l['ArtikelBezeichnung'];
            if(floatval($l['Rabatt'])>0)
            {
                $new[$i]['Rabatt_format'] = '-'.$l['Rabatt'].'%';
            }
            else
            {
                $new[$i]['Rabatt_format'] = '';
            }

            $new[$i]['LfdNummer'] = ($i+1);


            $i++;
        }

        return $new;
    }
    public function BerechneVorgangMwStGruppiert($id,$z='z')
    {
        // Diese Funktion Verwendung bei abschliessender Summenbildung

        $v = kasse::getVorgang($id,$z);

        $TotalBrutto = 0;

        $sql = 'SELECT
        MwstProzent,
        SUM(zSummeBrutto) AS SUMME,
        SUM(zSummeNetto) AS SUMME_NET,
        SUM(zSummeMwSt) AS MwStBetrag

        FROM kasse_'.$z.'journal
        WHERE VorgangID = '.$id.'
        GROUP BY
        MwstProzent
        ORDER BY MwstProzent ASC ';

        $list = DB::fetcharray($sql);
        $i=0;
        if($list==false) return false;
        foreach($list as $l)
        {
            $new['JournalFooter'][$i] = $l;

            $TotalBrutto = $TotalBrutto + $l['SUMME'];


            $i++;
        }

        $new['TotalBrutto'] = kasse::euro($TotalBrutto);

        return $new;
    }
    public function HinzuPreCheck($hinzu)
    {
        /*
        $request['vorgangID'] = $vorgang['id'];

        $request['ArtNr'] = $artikel['ArtNr'];

        $request['Anzahl'] = floatval($_REQUEST['Anzahl']);
        $request['Menge'] = floatval($_REQUEST['Menge']);
        $request['Mengeneinheit'] = strip_tags($_REQUEST['MengenEinheit']);
        $request['WarengruppenId'] = intval($artikel['kasse_wgid']);
        $request['EpBrutto'] = floatval($_REQUEST['P']);
        $request['CUR'] = CURRENCY;
        $request['MwstProzent'] = $artikel['MwStSatz'];
        $request['InsertDatetime'] = date("Y-m-d H:i:s");
        $request['InsertByBenutzerKurz'] = $_SESSION['kasse']['BenutzerKurz'];
        */
    }
    public function doKasseUpdateBediener()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Fehler '.print_r(@$_REQUEST,true).print_r(@$_SESSION['kasse'],true);



        if(empty($_REQUEST['Passwort']))
        {
            $ret['message'] = 'Passwort empty';
            return $ret;
        }
        if(empty($_REQUEST['BenutzerName']))
        {
            $ret['message'] = 'Name empty';
            return $ret;
        }

        $_REQUEST['Passwort'] = md5(strip_tags($_REQUEST['Passwort']));

        $ret['message'] = 'Fehler '.print_r(@$_REQUEST,true).print_r(@$_SESSION['kasse'],true);


        $sql = 'UPDATE kasse_benutzer SET
        Passwort="'.$_REQUEST['Passwort'].'",
        BenutzerName="'.strip_tags($_REQUEST['BenutzerName']).'"
        where ID="'.$_SESSION['kasse']['user_id'].'"';
        $do = DB::update($sql);
        kasse::kasse_log('UPDATE Benutzer',$_SESSION['kasse']['BenutzerName'].' -> '.strip_tags($_REQUEST['BenutzerName']));

        kasse_user::logout();

        $ret['success'] = 1;
        return $ret;
    }
}
?>