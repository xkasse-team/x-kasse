<?php
class kasse
{

    /*

    global Session:
    $_SESSION['kasse']['user_id']
    $_SESSION['kasse']['username']
    $_SESSION['kasse']['password']
    $_SESSION['kasse']['password']

     */
    /*
    private $fpdf_objekt;
    public function __construct()
    {
        $this->fpdf_objekt  = new PDF();
    }
    */

    function kasse_signatur()
    {
        $ret['REMOTE_ADDR'] = $_SERVER['REMOTE_ADDR'];

        $ret['SERVER_SIGNATURE'] = $_SERVER['SERVER_SIGNATURE'];
        $ret['SERVER_SOFTWARE'] = $_SERVER['SERVER_SOFTWARE'];
        $ret['SERVER_NAME'] = $_SERVER['SERVER_NAME'];
        $ret['DOCUMENT_ROOT'] = $_SERVER['DOCUMENT_ROOT'];
        $ret['SCRIPT_FILENAME'] = $_SERVER['SCRIPT_FILENAME'];
        $ret['REQUEST_TIME'] = $_SERVER['REQUEST_TIME'];

        /*
         *
         define('KASSEID','01');
         define('KASSEBEZEICHNUNG','Kasse Name');
         define('KASSEINSTALLDATETIME','2017-12-06 16:08:34');
         define('KASSEROOT','C:/XAZ/kasse/'); //SCRIPT_FILENAME
         define('KASSESERVERNAME','MYPC'); //SERVER_NAME
        */

        $ret['SystemInfo'] = 'SERVER: '.KASSESERVERNAME.' Kasse-ID: '.KASSEID.' '.KASSEBEZEICHNUNG.' '.KASSEINSTALLDATETIME.' '.KASSEROOT; // Markierung der Vorgänge

        return $ret;
    }
    public function isZahlungsart($str)
    {
        $str=trim($str);
        if(in_array(strtoupper($str),array('BAR','EC')))
        {
           return true;
        }
        else
        {
            return false;
        }
    }
    public function euro($float=0)
    {
        $float = number_format($float,2,".","");
        return $float;
    }
    public function drawKasseBediener()
    {
        $h = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/dialog/bediener_einstellungen.html',$_SESSION['kasse'],0,array());
        return $h;
    }
    public function drawWarengruppenTasten()
    {
        $wg = kasse::getWarengruppen();
        $ret='';
        if(is_array($wg))
        {
            foreach($wg as $w)
            {
                $ret.= '
                <button
                class="HinzuWarengruppe square"

                data-artnr="'.ARTNR_DEFAULT.'"
                data-warengruppe="'.$w['Warengruppe'].'"
                data-warengruppenid="'.$w['id'].'"
                data-mwst="'.$w['MwStSatz'].'"
                data-prefix="'.$w['DialogPrefix'].'"

                type="button"
                >'.$w['Warengruppe'].'</button>';
            }
        }

        return $ret;
    }
    public function draw_loginform()
    {
        $ret = array();
        $ret['success'] = 1;
        $ret['loginform'] = useful::ReadTemplateAndReplace('templates/alluser/loginform.html',array(),0,array());

        return $ret;
    }
    public function GetLastDatensicherung()
    {

        //$files = useful::searchdir ( KASSEBACKUP , 1 , "FILES" , 0 );

        // Datei für heute
        if(!file_exists(KASSEBACKUP.'SqlDump'.date("D").'.sql'))
        {
            kasse::Datensicherung();
            return '<span onClick="Datensicherung();">Nicht vorh. Jetzt erstellen</span>';
        }
        else
        {
            $finfo = @filemtime(KASSEBACKUP.'SqlDump'.date("D").'.sql');
            $fsize = @filesize(KASSEBACKUP.'SqlDump'.date("D").'.sql');

            $vorStd = (time()-$finfo) / (60*60);
            $mb = ceil(($fsize /1024 / 1000)).'MB';

            if($vorStd>12)
            {
                //kasse::Datensicherung();
                return 'SqlDump'.date("D").'.sql'.' '.$mb.' '.date("Y-m-d H:i:s",$finfo).' vor '.ceil($vorStd).' Std.';
            }
            else
            {
                return 'SqlDump'.date("D").'.sql'.' '.$mb.' '.date("Y-m-d H:i:s",$finfo).' vor '.ceil($vorStd).' Std.';
            }

        }


    }
    public function Datensicherung()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Datensicherung?';

        $KASSE_DBSERVER = KASSE_DBSERVER;
        $KASSE_DB=KASSE_DB;
        $KASSE_DBUSERNAME = KASSE_DBUSERNAME;




        try {
            $dump = new Ifsnop\Mysqldump\Mysqldump("mysql:host=$KASSE_DBSERVER;dbname=$KASSE_DB", $KASSE_DBUSERNAME, '');
            $dump->start(KASSEBACKUP.'SqlDump'.date("D").'.sql');
            $ret['success'] = 1;
            $ret['message'] = 'Datensicherung fertig';
            return $ret;
        } catch (\Exception $e) {
            $ret['message'] = 'mysqldump-php error: ' . $e->getMessage();
            return $ret;

        }

        return $ret;
    }
    public function getVorgangTmp($id=0)
    {
        // Vorsicht bei der Verwendung dieser Funktion: Die IDs der Positionen werden gelöscht

        $sql = 'select * FROM kasse_vorgaenge where id='.$id;
        $v=DB::fetcharray($sql);
        unset($v[0]['id']);

        $sql = 'select * FROM kasse_journal where VorgangID='.$id;
        $p=DB::fetcharray($sql);
        $i=0;
        if(is_array($p))
        {
            foreach($p as $pos)
            {
                $v[0]['Journal'][$i] = $pos;
                unset($v[0]['Journal'][$i]['ID']);
                $i++;
            }
        }

        return $v[0];

    }
    public function getVorgang($id=0,$z='z')
    {
        if(intval($id)==0) return false;



        $sql = 'select * from kasse_'.$z.'vorgaenge where id='.$id;
        $v = DB::fetcharray($sql);
        if($v!=false)
        {
            if(intval($v[0]['KdNr'])>0)
            {
                $v[0]['R_KdAdresse'] = trim($v[0]['R_Anrede'].' '.$v[0]['R_Vorname'].' '.$v[0]['R_Name']."\n".$v[0]['R_Strasse'].' '.$v[0]['R_PLZ']."\n".$v[0]['R_Ort']);
            }
            else
            {
                $v[0]['R_KdAdresse'] = '';
            }

            $v[0]['BonTextVorgangArt'] = kasse::getVorgangsBezeichnung($v[0]['VorgangArt']);//$texte['Bon'][$v[0]['VorgangArt']];
            $v[0]['CUR'] = CURRENCY;
            $v[0]['KasseID'] = KASSEID;

            return $v[0];
        }
        else
        {
            return false;
        }
    }

    public function getVorgangsBezeichnung($VorgangArt='')
    {
        // gibt den Titel eines BONs zurück z.B. "BAR VERKAUF"
        $arten = BELEG_TITEL_PRINT;
        return $arten[$VorgangArt];
    }

    public function draw_VorgaengeList()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['Liste'] = '';

        $list = kasse::getVorgaenge('z');

        $liste_show = array();
        foreach($list as $key => $item)
        {
            $liste_show[$key]['ID'] = $item['id'];
            $liste_show[$key]['BN'] = $item['BenutzerKurz'];
            $liste_show[$key]['DATUM'] = $item['AbschlussDatetime'];
            $liste_show[$key]['VA'] = $item['VorgangArt'];
            $liste_show[$key]['KD'] = $item['KdNr'];
            $liste_show[$key]['ZID'] = $item['Zid'];
            $liste_show[$key]['ZA'] = $item['ZahlungsArt'];
            $liste_show[$key]['SUM'] = kasse::euro($item['ControlSummeBrutto']);
            $liste_show[$key]['BON'] = '<button onclick="PrintBonKopie('.$item['id'].');">KOPIE</button>';
        }


        $ret['Liste'] = useful::showArrayAsTable($liste_show,'tablesort');

        return $ret;
    }

    public function getVorgaenge($z='z$')
    {

        $sql_add='';
        if(strtolower($_SESSION['kasse']['role'])!='admin')
        {
            $sql_add = ' WHERE BenutzerID='.$_SESSION['kasse']['user_id'];
        }

        //BELEG_TITEL_PRINT[$v[0]['VorgangArt']]

        $sql = 'select * from kasse_'.$z.'vorgaenge '.$sql_add.' ORDER BY id DESC';
        $v = DB::fetcharray($sql);
        if($v!=false)
        {
            return $v;
        }
        else
        {
            return false;
        }
    }
    public function kasse_log($type='',$text='')
    {
        $sql = 'INSERT INTO kasse_log
        (InsertDatetime, type, info, BenutzerKurz	)
        VALUES
        ("'.date("Y-m-d H:i:s").'","'.substr($type,0,19).'","'.$text.'","'.@$_SESSION['kasse']['BenutzerKurz'].'")';
        $do = DB::insert($sql);
    }

    public function getHeutigeLadenOffnen()
    {
        $r='<h2>Log File:</h2>';
        $sql = '

        Select * From kasse_log Where InsertDatetime >= "'.date("Y-m-d 00:00:01").'" ORDER BY id DESC ';
        $do = DB::fetcharray($sql);
        if(is_array($do))
        {
            foreach($do as $v)
            {
                $r.=$v['type'].' '.$v['BenutzerKurz'].' '.$v['info'].' '.$v['InsertDatetime'].'<br>';
            }
        }

        return $r;
    }

    public function checkInstall()
    {

        //echo dirname(__FILE__).'/../install.php';
        $er = array();
        if(file_exists(dirname(__FILE__).'/../install.php'))
        {
            $er[] = 'Installationsdatei <a href="install.php">install.php</a> löschen!';
        }
        if(count($er)>0)
        {
            return implode('<BR>',$er);
        }
        else
        {
            return 'OK';
        }
        // Tabellen da?
        // Einstellungen OK?
    }
    public function draw_kasse()
    {
        $check_install = kasse::checkInstall();

        if(!is_dir(KASSEABLAGE))
        {
            return KASSEABLAGE.' existiert nicht';
        }

        if(!is_dir(KASSEBACKUP))
        {
            return KASSEBACKUP.' existiert nicht';
        }


        if($check_install!='OK')
        {
            return $check_install;
        }

        $isloggedin = @kasse_user::is_logged_in();

        $template = 'templates/alluser/application.html';
        $contents = array();


        if($isloggedin==true)
        {
            // Vorgang öffnen:
            // TODO Wenn ein anderer als der letzte geöffnet wurde // Hier

            //print_r($_SESSION);



            if(isset($_REQUEST['v']))
            {
                if(intval($_REQUEST['v'])==0)
                {
                    //$vorgang = kasse::getLetztenOffenenVorgang();
                    $vorgang = kasse_dialog::getLetztenOffenenVorgang();
                    $_SESSION['kasse']['VorgangID']=$vorgang['id'];
                    header("location:index.php");
               }
            }
            else
            {
                $vorgang = kasse::getVorgang(intval($_SESSION['kasse']['VorgangID']),'');//::getLetztenOffenenVorgang();
            }





            // oder Öffnen if($_REQUEST...

            //kasse_dialog::BerechneVorgang($_SESSION['kasse']['VorgangID']);

            if(intval($vorgang['id'])==0)
            {
                kasse_user::logout();
                return 'Error: Vorgang konnte nicht geladen werden';
            }

            $kassye_sys = kasse::kasse_signatur();

            $contents['sys_info'] = print_r($kassye_sys,true).print_r($vorgang,true).print_r($_SESSION,true);

            $contents['BenutzerKurz'] = strtoupper($_SESSION['kasse']['BenutzerKurz']);
            $contents['Role'] = strtoupper($_SESSION['kasse']['role']);

            $contents['vorgang_art'] = $vorgang['VorgangArt'];
            $contents['vorgang_id'] = $vorgang['id'];
            $contents['KdNr'] = $vorgang['KdNr'];


            $contents['LetzteDatensicherung'] = kasse::GetLastDatensicherung();
            $contents['KASSE_IP'] = $_SERVER['SERVER_ADDR'];

            $contents['KasseAdmin'] = kasse_admin::drawKasseAdmin();

            $contents['KasseBediener'] = kasse::drawKasseBediener();

            $contents['WarengruppenTasten'] = kasse::drawWarengruppenTasten();



            $contents['WechselgeldHelper'] = useful::ReadTemplateAndReplace('templates/alluser/wechselgeld.html',array(),0,array());

            // neu 1.2.
            $contents['getHeutigeLadenOffnen']= kasse::getHeutigeLadenOffnen();

            $contents['application'] = useful::ReadTemplateAndReplace('templates/'.$_SESSION['kasse']['role'].'/kasse/kasse.html',$contents,0,array());

        }
        else
        {
            $contents['application'] = useful::ReadTemplateAndReplace('templates/alluser/loginform.html',array(),0,array());
        }



        return useful::ReadTemplateAndReplace($template,$contents,0,array());
    }
    public function GetMwSt()
    {
        $sql = 'select * from kasse_mwst';
        $list = DB::fetcharray($sql);
        if($list==false || count($list)==0)
        {
            return false;
        }
        return $list;
    }
    public function GetWarengruppen()
    {
        $sql = 'select
        kasse_warengruppen.*, kasse_mwst.MwStSatz
        from kasse_warengruppen
        LEFT JOIN kasse_mwst
        ON kasse_warengruppen.MwStID = kasse_mwst.MwStID
        order by kasse_warengruppen.Sortierung ASC';

        $list = DB::fetcharray($sql);
        if($list==false || count($list)==0)
        {
            return false;
        }
        foreach($list as $wg)
        {
            $retList[$wg['id']] = $wg;
        }
        return $retList;
    }
    public function GetWarengruppenCheck()
    {
        $sql = 'select
        kasse_warengruppen.id as KasseWgID,
        kasse_warengruppen.Warengruppe AS KasseWarengruppe,
        kasse_warengruppen.MwStID AS KasseMwStID,
        Warengruppen.Warengruppe AS StammWarengruppe,
        Warengruppen.WgID AS StammWgID

        from kasse_warengruppen
        LEFT JOIN Warengruppen ON kasse_warengruppen.id = Warengruppen.kasse_wgid
        order by kasse_warengruppen.Sortierung ASC';

        $list = DB::fetcharray($sql);
        if($list==false || count($list)==0)
        {
            return false;
        }

        return $list;
    }
    public function getZBericht($id)
    {
        $sql = 'SELECT * FROM kasse_zberichte WHERE id='.$id;
        $z = DB::fetcharray($sql);
        if($z==false)
        {
            return false;
        }
        else
        {
            return $z[0];
        }

    }
    public function doZBericht($vorschau=1)
    {
        // Erstellt Datensätze in kasse_zbericht
        // Ordnet abzurechnende Vorgänge ein (Update zid, bzw zflag)
        // Setzt einen Bericht aus vielen Zeilen zusammen, der am Ende gedruckt und als PDF gespeichert wird

        $printlines = array();
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Z-Bericht';


        if($_SESSION['kasse']['level']<2)
        {
            $ret['message'] = 'Kein Z-Bericht - UserLevel error';
            return $ret;
        }


        $sql = 'UPDATE kasse_zvorgaenge SET Zflag=0 ';
        $update = DB::update($sql);

        // ************************************************** TEest: leeren
/*
                $sql = 'UPDATE kasse_zvorgaenge SET Zid=0';
                $update = DB::update($sql);
                $sql = 'DELETE FROM kasse_zberichte ';
                $update = DB::delete($sql);
*/


        // Select from Vorgaenge ANZ(*ID) where Abschluss=1 GROUP BY AbschlusDatetime
        // je ermittelten Tag einen Z Abschluss erstellen
        // Vorgänge zuoordnen (Date)
        // je z-Abschluss, diesen berechnen und ausgeben (Print/Pdf)
        // Wenn kein PDF angelegt werden konnte, Abbruch!

        $sql = 'SELECT
                DATE_FORMAT(kasse_zvorgaenge.AbschlussDatetime,"%Y-%m-%d") AS zTag,
                count(kasse_zvorgaenge.id) AS AnzahlVorgaenge
                FROM
                kasse_zvorgaenge
                WHERE
                kasse_zvorgaenge.Abschluss=1
                AND
                kasse_zvorgaenge.Zid = 0
                AND
                kasse_zvorgaenge.VorgangArt IN ("'.implode('","',VORGANG_ARTEN).'")
                GROUP BY
                DATE_FORMAT(kasse_zvorgaenge.AbschlussDatetime,"%Y-%m-%d")
                ';
                $list = DB::fetcharray($sql);

        if($list==false)
        {
            $ret['message'] = 'Keine Umsätze - Abbruch';
            return $ret;
        }

        $zBerichteToDo = array();
        if($vorschau==1)
        {
            $i=0;
            foreach($list as $z)
            {

               $zBerichteToDo[$i]['id'] = $i+1;
               $zBerichteToDo[$i]['zTag'] = $z['zTag'];
               $i++;
               //$zBerichteToDo[$insert]['zTag'] = $z['zTag'];
            }
        }
        else
        {
            $i=0;
            foreach($list as $z)
            {
                $sql = 'INSERT INTO kasse_zberichte
                (InsertDatetime,BerichtTag,BenutzerKurz)
                VALUES
                ("'.date("Y-m-d H:i:s").'","'.$z['zTag'].'","'.$_SESSION['kasse']['BenutzerKurz'].'")
                ';
                $insert = DB::insert($sql);

                $zBerichteToDo[$i]['id'] = $insert;
                $zBerichteToDo[$i]['zTag'] = $z['zTag'];
                $i++;
                //$zBerichteToDo[$insert]['zTag'] = $z['zTag'];
            }
        }



        // Jedem Zbericht die Vorgänge des jew. tages zuordnen:
        if($vorschau==1)
        {
            foreach($zBerichteToDo as $key => $z)
            {
                $sql = 'UPDATE kasse_zvorgaenge
                SET Zflag='.$z['id'].'
                WHERE
                DATE_FORMAT(kasse_zvorgaenge.AbschlussDatetime,"%Y-%m-%d") = "'.$z['zTag'].'"
                AND
                kasse_zvorgaenge.Abschluss=1
                AND
                kasse_zvorgaenge.Zid = 0
                AND
                kasse_zvorgaenge.VorgangArt IN ("'.implode('","',VORGANG_ARTEN).'")';

                $update = DB::update($sql);
            }
        }
        else
        {
            foreach($zBerichteToDo as $key => $z)
            {
                $sql = 'UPDATE kasse_zvorgaenge
                SET Zid='.$z['id'].'
                WHERE
                DATE_FORMAT(kasse_zvorgaenge.AbschlussDatetime,"%Y-%m-%d") = "'.$z['zTag'].'"
                AND
                kasse_zvorgaenge.Abschluss=1
                AND
                kasse_zvorgaenge.Zid = 0
                AND
                kasse_zvorgaenge.VorgangArt IN ("'.implode('","',VORGANG_ARTEN).'")';

                $update = DB::update($sql);
            }
        }

        //Zum testen, wieviele Z Berichte erstellt werden müssen:
        /*
        $ret['message'] = useful::showArrayAsTable($zBerichteToDo);
        return $ret;
        */

        $ZBericht=array();

        foreach($zBerichteToDo as $z)
        {
            $ZBericht[] = kasse::BerechneZAbschluss($z['id'],$vorschau,$z['zTag']);
        }

        // Es können mehrere sein...
        $err = array();
        foreach($ZBericht as $key => $value)
        {
            $printlines = array();

            $tmp = useful::ReadTemplateAndReplace('templates/print/BonHeader.txt',array(),0,array());
            $headerar = @explode("\n",$tmp);
            foreach($headerar as $header)
            {
                $printlines[] = $header;
            }


            if($vorschau==1)
            {
                $printlines[]= 'Tagesabschluss Vorschau';
                $printlines[]= '';
                $printlines[]= '***********';
                $printlines[]= '';
                $printlines[]= 'für: '.date("Y-m-d H:i:s");
            }
            else
            {
                $printlines[]= 'Tagesabschluss Z-Bericht';
                $printlines[]= '';
                $printlines[]= '***********';
                $printlines[]= '';
                $printlines[]= 'Z-Bericht ID: '.$value['zid'];
                $printlines[]= 'Erstellungsdatum: '.$value['InsertDatetime'];
                $printlines[]= 'für: '.$value['BerichtTag'];
            }



            $printlines[]= 'Währung: '.CURRENCY;
            $printlines[]= 'KASSE-ID: '.KASSEID;
            $printlines[]= 'KASSEBEZEICHNUNG: '.KASSEBEZEICHNUNG;
            $printlines[]= '';
            $printlines[]= 'Umsatz nach Steuern:';
            $string = array();
            $string[0] = 'NETTO';
            $string[1] = 'zu';
            $string[2] = 'MWST';
            $string[3] = 'BRUTTO';

            $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);

            if(is_array($value['UmsatzberichtNachMwStGruppiert']))
            {
                foreach($value['UmsatzberichtNachMwStGruppiert'] as $values)
                {
                    $string = array();
                    $string[0] = $values['NETTO'];
                    $string[1] = $values['M'].'%';
                    $string[2] = $values['MWST'];
                    $string[3] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }

            $printlines[]= '';
            $printlines[]= 'TOTAL:';

            //TOTAL
            if(is_array($value['Total']))
            {
                foreach($value['Total'] as $values)
                {
                    $string = array();
                    $string[0] = $values['NETTO'];
                    $string[1] = '-';
                    $string[2] = $values['MWST'];
                    $string[3] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }


            $printlines[]= '';
            $printlines[]= 'Umsatz nach Zahlungsart:';

            if(is_array($value['ZahlungsArtBericht']))
            {
                foreach($value['ZahlungsArtBericht'] as $values)
                {

                    $string = array();
                    //$string[0] = $values['BelegInfo'];
                    $string[0] = $values['ZahlungsArt'];

                    $string[1] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }
            $printlines[]= '';
            $printlines[]= 'Umsatz nach Bediener:';

            if(is_array($value['BenutzerKurzBericht']))
            {
                foreach($value['BenutzerKurzBericht'] as $values)
                {

                    $string = array();
                    //$string[0] = $values['BelegInfo'];
                    $string[0] = $values['BenutzerKurz'];

                    $string[1] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }

            $printlines[]= '';
            $printlines[]= '';

            $string = array();
            $string[0] = 'NETTO';
            $string[1] = 'zu';
            $string[2] = 'MWST';
            $string[3] = 'BRUTTO';

            $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);

            if(is_array($value['WarengruppenBericht']))
            {
                foreach($value['WarengruppenBericht'] as $values)
                {
                    $string = array();
                    $string[1] = $values['Warengruppe'].' '.$values['BelegInfo'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);

                    $string = array();
                    //$string[0] = $values['BelegInfo'];
                    $string[0] = $values['NETTO'];
                    $string[1] = $values['M'].'%';
                    $string[2] = $values['MWST'];
                    $string[3] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }


            $printlines[]='__________________________________________';

            if(is_array($value['WarengruppenBerichtSumme']))
            {
                foreach($value['WarengruppenBerichtSumme'] as $values)
                {

                    $string = array();
                    //$string[0] = $values['BelegInfo'];
                    $string[0] = $values['NETTO'];
                    $string[1] = '-';
                    $string[2] = $values['MWST'];
                    $string[3] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }


            /*
            $printlines[]= '';
            $printlines[]= 'Vorgänge:';
            if(is_array($value['VorgaengeBericht']))
            {
                foreach($value['VorgaengeBericht'] as $values)
                {

                    $string = array();
                    //$string[0] = $values['BelegInfo'];
                    $string[0] = $values['VorgangArt'];
                    $string[1] = $values['ANZAHL'];
                    $string[2] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }
            */
            $printlines[]= '';
            $printlines[]= 'Belege:';

            $string = array();
            $string[0] = 'Vorgang';
            $string[1] = 'Anzahl';
            $string[2] = 'BRUTTO';

            $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);

            if(is_array($value['BelegInfoBericht']))
            {
                foreach($value['BelegInfoBericht'] as $values)
                {

                    $string = array();

                    $string[0] = $values['VorgangArt'];
                    $string[1] = $values['ANZAHL'];
                    $string[2] = $values['BRUTTO'];

                    $printlines[]=useful::ArrayToJustifiedString($string,BONMAXLENGTH);
                }
            }
            //$ret['message'].=useful::showArrayAsTable($value['JournalBericht']);
            $printlines[]= '';
            $printlines[]= '';
            $printlines[]= 'KASSEINSTALLDATETIME: '.KASSEINSTALLDATETIME;
            $printlines[]= 'KASSEROOT: '.KASSEROOT;
            $printlines[]= 'KASSESERVERNAME: '.KASSESERVERNAME;
            $printlines[]= '';


            // Ende Bericht


            if($vorschau==0)
            {
                $printed = kasse_print::virtualPrintArray(
                    KASSEABLAGE.'ZBericht_'.$value['zid'].'.pdf',
                    $printlines,
                    0);
                if($printed['success']==1)
                {
                    $sql = 'UPDATE kasse_zberichte
                  SET zBerichtgedruckt = 1,
                  WHERE id='.$value['zid'].'
                 ';

                  $update = DB::update($sql);
                }
                else
                {
                    $err[$value['zid']] = print_r($printed,true);

                }
            }
            else
            {
                $printed = kasse_print::virtualPrintArray(
                    KASSEABLAGE.'ZBericht_'.$value['zid'].'.pdf',
                    $printlines,
                    1);
            }



            $ret['message'].='<textarea style="font-family: Courier New;text-align:left;width:80%;height: 400px;font-size: 12px;margin: 20px;">'.$printed['content'].'</textarea>';

        }

        if(count($err)>0)
        {
            $ret['success'] = 0;
            $ret['message'] = 'Fehler bei Druck '.print_r($err,true);
            return $ret;
        }

        $ret['success'] = 1;

        return $ret;
    }
    public function BerechneZAbschluss($Zid=0,$vorschau=1,$BerichtTag='')
    {
        if($_SESSION['kasse']['level']<2)
        {
            return '';
        }

       // Diese Funktion summiert die Umsätze aller Vorgänge, die in "Zid" mit der abzurechnenden kasse_zberichte.id markiert sind



        if(intval($Zid)==0) return 'Zid ist 0';

        if($vorschau==1)
        {
            $list['zid'] = 0;
            $list['InsertDatetime'] = date("Y-m-d H:i:s");
            $list['BerichtTag'] = $BerichtTag;

            $flaged_sql = ' kasse_zvorgaenge.Zflag='.$Zid.' ';
        }
        else
        {
            $zBericht = kasse::getZBericht($Zid);

            $list['zid'] = $zBericht['id'];
            $list['InsertDatetime'] = $zBericht['InsertDatetime'];
            $list['BerichtTag'] = $zBericht['BerichtTag'];

            $flaged_sql = ' kasse_zvorgaenge.Zid='.$Zid.' ';
        }


        // ***** TOTAL
        $sql = 'SELECT
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST
                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"

                ';
        $list['Total'] = DB::fetcharray($sql);



        // ***** UmsatzberichtNachMwStGruppiert
        $sql = 'SELECT
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST,
                kasse_zjournal.MwstProzent AS M
                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"
                GROUP BY
                kasse_zjournal.MwstProzent
                ORDER BY kasse_zjournal.MwstProzent DESC
                ';
        $list['UmsatzberichtNachMwStGruppiert'] = DB::fetcharray($sql);




        // **** WarengruppenBericht
        $sql = 'SELECT
                kasse_zvorgaenge.VorgangArt,
                kasse_zjournal.WarengruppenId AS WGID,
                kasse_warengruppen.Warengruppe,
                kasse_zjournal.BelegInfo,

                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST,

                kasse_zjournal.MwstProzent AS M
                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                LEFT JOIN kasse_warengruppen ON kasse_warengruppen.id = kasse_zjournal.Warengruppenid
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"
                GROUP BY
                kasse_zvorgaenge.VorgangArt,
                kasse_warengruppen.Warengruppe,
                kasse_zjournal.WarengruppenId,
                kasse_zjournal.BelegInfo,
                kasse_zjournal.MwstProzent
                ORDER BY kasse_zjournal.MwstProzent, kasse_warengruppen.Warengruppe,  kasse_zjournal.BelegInfo ASC
                ';

        $list['WarengruppenBericht'] = DB::fetcharray($sql);



                // **** WarengruppenBerichtSumme
        $sql = 'SELECT
                kasse_zvorgaenge.VorgangArt,
                kasse_zjournal.WarengruppenId AS WGID,
                kasse_warengruppen.Warengruppe,
                kasse_zjournal.BelegInfo,

                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST,

                kasse_zjournal.MwstProzent AS M
                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                LEFT JOIN kasse_warengruppen ON kasse_warengruppen.id = kasse_zjournal.Warengruppenid
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"

                ';

        $list['WarengruppenBerichtSumme'] = DB::fetcharray($sql);




        //$list['WarengruppenBericht'] = DB::fetcharray($sql);


        // ***** ZahlungsArtBericht
        $sql = 'SELECT

                kasse_zvorgaenge.ZahlungsArt,
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST,
                kasse_zjournal.MwstProzent AS M

                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"
                GROUP BY
                kasse_zvorgaenge.ZahlungsArt
                ';
        $list['ZahlungsArtBericht'] = DB::fetcharray($sql);

        // ***** Bediener Bericht
        $sql = 'SELECT

                kasse_zvorgaenge.BenutzerKurz,
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO,
                ROUND(SUM(kasse_zjournal.zSummeNetto),2) AS NETTO,
                ROUND(SUM(kasse_zjournal.zSummeMwSt),2) AS MWST,
                kasse_zjournal.MwstProzent AS M

                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                WHERE
                '.$flaged_sql.'
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_STORNO.'"
                AND
                kasse_zvorgaenge.VorgangArt!="'.VORGANG_ART_OFFENERVORGANG.'"
                GROUP BY
                kasse_zvorgaenge.BenutzerKurz
                ';
        $list['BenutzerKurzBericht'] = DB::fetcharray($sql);


        //,ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO
        // LEFT JOIN kasse_zjournal ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
        // ******** VorgaengeBericht
        $sql = 'SELECT
                kasse_zvorgaenge.VorgangArt,
                COUNT(distinct kasse_zvorgaenge.id) AS ANZAHL,
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO
                FROM kasse_zvorgaenge
                LEFT JOIN kasse_zjournal ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
                WHERE
                '.$flaged_sql.'
                GROUP BY
                kasse_zvorgaenge.VorgangArt
                ';
        $list['VorgaengeBericht'] = DB::fetcharray($sql);


        // ******** BelegInfoBericht
        $sql = 'SELECT
                kasse_zvorgaenge.VorgangArt,
                COUNT(distinct kasse_zvorgaenge.id) AS ANZAHL,
                ROUND(SUM(kasse_zjournal.zSummeBrutto),2) AS BRUTTO
                FROM kasse_zjournal
                LEFT JOIN kasse_zvorgaenge ON (kasse_zvorgaenge.id = kasse_zjournal.VorgangID)
                WHERE
                '.$flaged_sql.'
                GROUP BY
                kasse_zvorgaenge.VorgangArt
                ';
        $list['BelegInfoBericht'] = DB::fetcharray($sql);


        // ****** JournalBericht des Tages
        if($vorschau==0)
        {

            $list['JournalBericht'] = kasse::getJournalExport($Zid);

            $table = kasse_print::printTable(KASSEABLAGE.'ZJournal_'.$zBericht['id'].'.pdf',$list['JournalBericht']);

            // ****** JournalBericht des gesamt

            $list['JournalBerichtTotal'] = kasse::getJournalExport(0);

            $table = kasse_print::printTable(KASSEABLAGE.'ZJournalTotal.pdf',$list['JournalBerichtTotal']);

        }
        /*
        $do = DB::fetcharray($sql);
        foreach($do as $key => $value)
        {
            $vorgang = BerechneVorgangMwStGruppiertXX($value['id'],'z');
            $list['JournalBericht'][$key] = $value;
            $list['JournalBericht'][$key]['NETTO'] = kasse::euro(($value['BRUTTO'] / (100+$value['M']) * 100));
            $list['JournalBericht'][$key]['MWST'] = kasse::euro($value['BRUTTO'] - $list['WarengruppenBerichtSumme'][$key]['NETTO']);
        }$list['JournalBericht'] = DB::fetcharray($sql);
        */


        /* repair

        UPDATE kasse_zjournal SET
        zSummeBrutto = ROUND((Anzahl * EpBrutto) / 100 * (100-Rabatt),2),
        zSummeNetto = ROUND((zSummeBrutto / (100+MwstProzent)) * 100 , 2),
        zSummeMwSt = ROUND(zSummeBrutto - zSummeNetto,2)


        */



//



        return $list;


        return $new;
    }

    public function getJournalExport($zid=0)
    {
        // ****** JournalBericht
        $add_sql='';

        if(intval($zid)>0)
        {
            $add_sql = 'WHERE
                        kasse_zvorgaenge.Zid='.$zid;
        }

        $sql = 'SELECT
        kasse_zjournal.id AS id,
        kasse_zvorgaenge.id AS VorgangID,
        kasse_zvorgaenge.VorgangArt,
        kasse_zvorgaenge.BenutzerID,
        kasse_zvorgaenge.InsertDatetime,
        kasse_zvorgaenge.Abschluss,
        kasse_zvorgaenge.AbschlussDatetime,
        kasse_zvorgaenge.KdNr,
        kasse_zvorgaenge.BenutzerKurz,
        kasse_zvorgaenge.BonGedruckt,
        kasse_zvorgaenge.BonGedrucktDatetime,
        kasse_zvorgaenge.ZahlungsArt,
        kasse_zvorgaenge.Zid,
        kasse_zvorgaenge.SystemInfo,
        kasse_zvorgaenge.R_Anrede,
        kasse_zvorgaenge.R_Vorname,
        kasse_zvorgaenge.R_Name,
        kasse_zvorgaenge.R_Ansprechperson,
        kasse_zvorgaenge.R_Strasse,
        kasse_zvorgaenge.R_PLZ,
        kasse_zvorgaenge.R_Ort,
        kasse_zvorgaenge.R_Land,

        kasse_zjournal.ID,
        kasse_zjournal.BelegInfo,
        kasse_zjournal.WarengruppenId,
        kasse_zjournal.ArtNr,
        kasse_zjournal.VorgangID,
        kasse_zjournal.ArtikelBezeichnung,
        kasse_zjournal.Anzahl,
        kasse_zjournal.EpBrutto,
        kasse_zjournal.zSummeBrutto,
        kasse_zjournal.zSummeNetto,
        kasse_zjournal.zSummeMwSt,
        kasse_zjournal.CUR,
        kasse_zjournal.Rabatt,
        kasse_zjournal.MwstProzent,
        kasse_zjournal.InsertDatetime,
        kasse_zjournal.InsertByBenutzerKurz,

        kasse_zjournal.Menge,
        kasse_zjournal.Mengeneinheit,



        kasse_warengruppen.Warengruppe,
        kasse_warengruppen.MwStID,

        kasse_warengruppen.DialogPrefix


        	FROM
        	kasse_zjournal

        	LEFT JOIN kasse_zvorgaenge ON kasse_zvorgaenge.id = kasse_zjournal.VorgangID
        	LEFT JOIN kasse_warengruppen ON kasse_zjournal.WarengruppenId = kasse_warengruppen.id
            '.$add_sql.'
        	ORDER BY kasse_zjournal.id ASC
                ';
        //$sql = 'SHOW COLUMNS FROM kasse_warengruppen';
        $list = DB::fetcharray($sql);
        return $list;
    }

    public function BerechneVorgangMwStGruppiertXX($id,$z='z')
    {
        $v = kasse::getVorgang($id,$z);

        $TotalBrutto = 0;

        $sql = 'SELECT
        MwstProzent,
        SUM(zSummeBrutto) AS SUMME,
        SUM(zSummeBrutto) AS SUMME_NET,
        SUM(zSummeMwSt) AS MwStBetrag
        FROM kasse_'.$z.'journal
        WHERE VorgangID = '.$id.'
        GROUP BY
        MwstProzent
        ORDER BY MwstProzent ASC ';

        $list = DB::fetcharray($sql);
        $i=0;
        foreach($list as $l)
        {
            $new['JournalFooter'][$i] = $l;

            $TotalBrutto = $TotalBrutto + $l['SUMME'];


            $i++;
        }

        $new['TotalBrutto'] = kasse::euro($TotalBrutto);

        return $new;
    }
}
?>
