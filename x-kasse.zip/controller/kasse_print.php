<?php
require dirname(__FILE__).'/../libraries_3rdparty/php-escpos-php-development/autoload.php';
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\EscposImage;


class kasse_print
{
    function addSpaces($int=1)
    {
        $ret='';
        for ($i = 1; $i <= $int; $i++)
        {
            $ret.=' ';
        }
        return $ret;
    }
    function draw_bon($vorgang=array())
    {
        //
    }
    public function virtualPrintArray($pdfpath='',$array=array(),$debug=0)
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'virtualPrintArray return debug: '.$debug;
        $ret['content'] = 'no content';



        // Bon drucker umgehen:

        // $debug=1;

        // Diese Funktion liefert zeilenweise an
        // PDF und
        // Printer
        // zum Debuggen debug==1 als ganzen String mit "\n"

        //$this->fpdf_objekt  = new PDF();
        if(!is_dir(str_replace(basename($pdfpath),'',$pdfpath)))
        {
            $ret['message'] = 'Ablageordner existiert nicht: '.$pdfpath.' '.basename($pdfpath);
            return $ret;
        }
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetLeftMargin(30);

        //$pdf->SetFont('Courier','B',16);
        //$pdf->Cell(90,10,'Tagesabschluss Z-Bericht',0,1,'L');
        //$pdf->Ln();
        $pdf->SetFont('Courier','',9);
        foreach($array as $line)
        {
            $pdf->Cell(90,5,utf8_decode($line) ,0,1,'L');
        }
        $pdf->Output('F',$pdfpath,false);
        // Ende PDF

        $ret['content'] = implode("\n",$array);


        if(!file_exists($pdfpath))
        {
            return $ret;
        }

        // wenn etwas gedruckt wird, wird auch die lade geöffnet:
        kasse::kasse_log('LADE OFFNEN','');

        // Kein Bon Druck BONPRINTER_USE
        if(BONPRINTER_USE==0)
        {
            $ret['success'] = 1;
            $ret['content'] = implode("\n",$array);

            return $ret;
        }


        // Start BON Drucker

        $connector = new WindowsPrintConnector(KASSE_BONPRINTER);
        $printer = new Printer($connector);
        $printer -> initialize();
        $printer -> selectPrintMode();
        $printer -> setJustification(Printer::JUSTIFY_LEFT);
        foreach($array as $line)
        {
            $printer -> setJustification(Printer::JUSTIFY_LEFT);
            $printer -> text($line);
            $printer -> feed();
        }
        $printer -> feed();
        $printer -> feed();
        $printer -> cut();
        $printer -> pulse(); // hinzu v 1.2.

        $printer -> close();

        if(file_exists($pdfpath) && $debug==0)
        {
            $ret['success'] = 1;
        }

        return $ret;
    }


    function printTable($pdfpath='',$array)
    {
        // Funktion zum Speichern eines Arrays als CSV in PDF

        $pdf = new FPDF();
        $pdf->AddPage("L","A3");

        $pdf->SetFont('Courier','',7);

        if(!is_array($array[0])) return false;
        // Header
        $head = array();
        foreach($array[0] as $key => $x)
        {
            $head[] = $key;
        }
        $array[0] = $head;
        foreach($array as $row)
        {
            $pdf->MultiCell(0,5,'"'.str_replace("\n",'',utf8_decode(@implode('";"',$row))).'"',0);
            $pdf->Ln();
        }
        $pdf->Output('F',$pdfpath,false);
    }

    function BonPrinterTest()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Try to Print Bon';

        kasse::kasse_log('LADE OFFNEN','');

        $connector = new WindowsPrintConnector(KASSE_BONPRINTER);
        $printer = new Printer($connector);
        $printer -> initialize();
        $printer -> setJustification(Printer::JUSTIFY_CENTER);
        $printer -> text('TEST');
        $printer -> feed();
        $printer -> cut();
        $printer -> pulse();
        $printer -> close();

        $ret['debug'] = print_r($printer,true);

        return $ret;

        //$ret['success'] = 1;
    }

    function PrintBon($vorgangID=0,$usebonprinter=1)
    {
        $MAXLENGTH = 42;

        // $usebonprinter==0 = kein Druck

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Try to Print Bon '.$usebonprinter;



        if(intval($vorgangID)==0)
        {
            $ret['message'] = 'Vorgang nicht gefunden';
            return $ret;
        }

        $vorgang= kasse::getVorgang($vorgangID,'z');
        if($vorgang==false)
        {
            $ret['message'] = 'Vorgang nicht gefunden';
            return $ret;
        }
        $positionen = kasse_dialog::BerechneVorgangGruppiert($vorgang['id'],'GROUPED','z');

        $cart = array();
        $i=0;

        //$WarengruppeHeadline = '';

        foreach($positionen as $p)
        {
            $p['Mengeneinheit'] = strtoupper($p['Mengeneinheit']);
            $p['ArtNr'] = strtoupper($p['ArtNr']);

            //##Anzahl## x ##Menge####Mengeneinheit## ##ArtNr## ##EpBrutto_format## ##Rabatt_format## ##MwstProzent## ##zSummeBrutto##

            $cart[$i][0] = useful::ArrayToJustifiedString(
                array(
                    '*    ',
                    $p['BelegInfo'].' '.$p['Warengruppe'].' '.$p['ArtikelBezeichnung_cut']
                ),
                BONMAXLENGTH, 1
            );

            $cart[$i][1] = useful::ArrayToJustifiedString(
                array(
                    $p['Anzahl'].' x '.$p['Menge'].$p['Mengeneinheit'],
                    $p['ArtNr'],
                    $p['EpBrutto_format'],
                    $p['Rabatt_format'],
                    'M'.$p['MwstProzent'],
                    kasse::euro($p['zSummeBrutto'])
                ),
                BONMAXLENGTH
            );


            //$WarengruppeHeadline = $p['Warengruppe'];
            $i++;
        }

        $vvv = kasse_dialog::BerechneVorgangMwStGruppiert($vorgang['id'],'z');

        $mwst=array();
        $mwst[]='Mehrwertsteuer:';
        foreach($vvv['JournalFooter'] as $sum)
        {
            $mwst[]= kasse::euro($sum['SUMME_NET']).' netto mit MwSt '.$sum['MwstProzent'].'% = '.kasse::euro($sum['MwStBetrag']);
            //$sum['SUMME']
        }

        $Total = $vvv['TotalBrutto'];



        $bon['header'] = useful::ReadTemplateAndReplace('templates/print/BonHeader.txt',$vorgang,1,array());
        $bon['header2'] = useful::ReadTemplateAndReplace('templates/print/BonHeader2.txt',$vorgang,1,array());
        $bon['footer'] = useful::ReadTemplateAndReplace('templates/print/BonFooter.txt',$vorgang,1,array());

        if($usebonprinter==0)
        {
            $ret['success'] = 1;

            $out = array();

            $out[] = $bon['header'];

            if(intval($vorgang['BonGedruckt'])==1)
            {
                $out[] = BONKOPIETEXT;
            }
            $out[] = $vorgang['BonTextVorgangArt'];
            $out[] = $bon['header2'];

            $out[] = 'Anzahl x Menge ArtNr Einzelpreis MwSt Zeilensumme';

            foreach($cart as $line)
            {
                $out[] = $line[0];
                $out[] = $line[1];
            }

            foreach($mwst as $line)
            {
                $out[] = $line;
            }
            $out[] = "Summe: ".CURRENCY.' '.$Total;


            if($vorgang['ZahlungsArt']=='BAR')
            {
                if($vorgang['ControlSummeBar'] >= $Total)
                {
                    $out[] = "in BAR: ".CURRENCY.' '.kasse::euro($vorgang['ControlSummeBar']);
                    $out[] = "Wechselgeld: ".CURRENCY.' '.kasse::euro($vorgang['ControlSummeBar']-$Total);
                }
            }
            $out[] = $bon['footer'];

            kasse_print::PrintSomethingToPdf(KASSEABLAGE.'BON_'.$vorgang['id'].'.pdf',@implode("\n",$out));


            return $ret;
        }


        $connector = new WindowsPrintConnector(KASSE_BONPRINTER);
        $printer = new Printer($connector);
        $printer -> initialize();
        $printer -> setJustification(Printer::JUSTIFY_CENTER);


        try {
            $logo = EscposImage::load(KASSE_BONLOGOPATH, false);
            $imgModes = array(
                Printer::IMG_DEFAULT
                //Printer::IMG_DOUBLE_WIDTH,
                //Printer::IMG_DOUBLE_HEIGHT,
                //Printer::IMG_DOUBLE_WIDTH | Printer::IMG_DOUBLE_HEIGHT
            );
            foreach ($imgModes as $mode) {
                $printer -> bitImage($logo, $mode);
            }
        } catch (Exception $e) {
            $printer -> text($e -> getMessage() . "\n");
        }



        $printer -> text($bon['header']);
        $printer -> feed();


        if(intval($vorgang['BonGedruckt'])==1)
        {
            $printer -> selectPrintMode(Printer::MODE_DOUBLE_WIDTH);
            $printer -> text(BONKOPIETEXT."\n");
            $printer -> feed();
        }

        $printer -> selectPrintMode(Printer::MODE_DOUBLE_WIDTH);
        $printer -> text($vorgang['BonTextVorgangArt']."\n");



        $printer -> feed();
        $printer -> selectPrintMode();

        //BonTextVorgangArt

        $printer -> setJustification(Printer::JUSTIFY_LEFT);
        $printer -> text($bon['header2']);
        $printer -> feed(2);

        foreach($cart as $line)
        {
            $printer -> setJustification(Printer::JUSTIFY_LEFT);
            $printer -> text($line[0]);
            $printer -> feed();
            $printer -> setJustification(Printer::JUSTIFY_LEFT);
            $printer -> text($line[1]);
            $printer -> feed();

        }
        $printer -> feed();
        $printer -> setJustification(Printer::JUSTIFY_LEFT);
        foreach($mwst as $line)
        {
            $printer -> text($line);
            $printer -> feed();
        }
        $printer -> feed();
        $printer -> setJustification(Printer::JUSTIFY_RIGHT);
        $printer -> selectPrintMode(Printer::MODE_DOUBLE_WIDTH);
        $printer -> text("Summe: ".CURRENCY.' '.$Total."\n");
        $printer -> feed();
        $printer -> feed();
        $printer -> selectPrintMode();

        if($vorgang['ZahlungsArt']=='BAR')
        {
            if($vorgang['ControlSummeBar'] >= $Total)
            {
                $printer -> text("in BAR: ".CURRENCY.' '.kasse::euro($vorgang['ControlSummeBar'])."\n");
                $printer -> feed();
                $printer -> text("Wechselgeld: ".CURRENCY.' '.kasse::euro($vorgang['ControlSummeBar']-$Total)."\n");
                $printer -> feed();
            }
        }

        $printer -> setJustification(Printer::JUSTIFY_CENTER);
        $printer -> text($bon['footer']);

        $printer -> feed();
        $printer -> cut();
        $printer -> pulse();
        $printer -> close();

        kasse::kasse_log('LADE OFFNEN','Verkauf');

        $ret['success'] = 1;

        return $ret;



    }
    function PrintSomethingToPdf($filepath,$content)
    {
        if(file_exists($filepath))
        {
            return false;
        }

        $pdf = new FPDF();
        $pdf->AddPage("L","A3");
        $pdf->SetFont('Courier','',9);
        $pdf->MultiCell(0,5,utf8_decode($content),0);
        $pdf->Ln();
        $pdf->Output('F',$filepath,false);
        return true;

    }
}

?>