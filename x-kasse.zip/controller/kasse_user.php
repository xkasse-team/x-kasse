<?php
class kasse_user
{
    function UserGetLevel($role='')
    {
        $level['kassierer']['level']=1;
        $level['hauptkassierer']['level']=2;
        $level['admin']['level']=3;

        $levelsallow[1] = array('Kasse','Bondruck','Storno');
        $levelsallow[2] = array('Kasse','Bondruck','Storno','Tagesabschluss');
        $levelsallow[3] = array('Kasse','Bondruck','Storno','Tagesabschluss', 'Administration');

        return intval($level[strtolower($role)]['level']);
    }

    function is_logged_in()
    {
        // Prüft Session ob gültig

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Anmeldung nicht erfolgreich';

        $sql = 'select * from kasse_benutzer where BenutzerKurz="'.strip_tags(@$_SESSION['kasse']['BenutzerKurz']).'" AND Passwort="'.strip_tags(@$_SESSION['kasse']['Passwort']).'"';
        $try = DB::fetcharray($sql);

        if($try!=false && strip_tags(@$_SESSION['kasse']['BenutzerKurz']) == $try[0]['BenutzerKurz'] )
        {
            return true;
        }
        else
        {
            return false;
        }
        return false;
    }
    function isBenutzer($UserId=0)
    {
        // Prüft Session ob gültig

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'User existiert nicht';

        $sql = 'select * from kasse_benutzer where ID="'.intval($UserId).'" ';
        $try = DB::fetcharray($sql);

        if(intval($try[0]['ID']) == intval($UserId))
        {
            return true;
        }
        else
        {
            return false;
        }
        return false;
    }
    public function Xlogin()
    {
        /*
        global $_SESSION;

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Anmeldung nicht erfolgreich';

        $try = kasse_user::UserAuth(@$_REQUEST);

        if($try['success']==1)
        {
            $ret['success'] = 1;
            $ret['message'] = 'Angemeldet';

            $_SESSION['kasse']['user_id'] = $try['ID'];
            $_SESSION['kasse']['BenutzerKurz'] =$try['user']['BenutzerKurz'];
            $_SESSION['kasse']['Passwort'] = $try['user']['Passwort'];
            $_SESSION['kasse']['role'] = $try['user']['role'];
            return $ret;
        }
        else
        {
            return $ret;
        }
        */
    }
    public function logout()
    {
        unset($_SESSION['kasse']);

        $ret = array();
        $ret = kasse::draw_loginform();

        $ret['success'] = 1;

        return $ret;
    }
    public function login($request=array())
    {

        // Prüft Request, setzt Session

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Anmeldung nicht erfolgreich';//.print_r(@$request,true);

        $sql = 'select * from kasse_benutzer where BenutzerKurz="'.strip_tags(@$request['BenutzerKurz']).'" AND Passwort="'.md5(strip_tags(@$request['Passwort'])).'"';
        $try = DB::fetcharray($sql);

        if($try!=false && strip_tags(@$request['BenutzerKurz']) == $try[0]['BenutzerKurz'] )
        {
            $ret['success'] = 1;
            $ret['message'] = 'Willkommen';



            $_SESSION['kasse']['user_id'] = $try[0]['ID'];
            $_SESSION['kasse']['BenutzerKurz'] =$try[0]['BenutzerKurz'];
            $_SESSION['kasse']['BenutzerName'] =$try[0]['BenutzerName'];
            $_SESSION['kasse']['Passwort'] = $try[0]['Passwort'];
            $_SESSION['kasse']['role'] = strtolower($try[0]['Role']);
            $_SESSION['kasse']['level'] = kasse_user::UserGetLevel($_SESSION['kasse']['role']);

            // ggf anlegen:
            // getLetztenOffenenVorgang braucht $_SESSION['kasse']['user_id']
            $LetzterVorgang = kasse_dialog::getLetztenOffenenVorgang();

            $_SESSION['kasse']['VorgangID'] = $LetzterVorgang['id'];


            return $ret;
        }
        else
        {
            return $ret;
        }

    }
}
?>