<?php

/*
 * Alle Funktionen hier basieren auf identischen Tabelelleneigenschaften von Kasse/AccessDB
 *
 *
 * */

class ArtikelStammDB
{
    function getArtikel($by='',$value='',$quick=0)
    {
        if($quick==1)
        {
            $sql1 = 'ArtNr';
        }
        else
        {
            $sql1 = '*';
        }
        $Sql = 'Select Artikel.'.$sql1.',

            CONCAT
            (
            IF(isNull(Artikel.Max_Temp),"",CONCAT(Artikel.Max_Temp,"°C")),
            " ",
            IF(isNull(Artikel.Fussnoten),"",CONCAT("",Artikel.Fussnoten)),
            " ",
            IF(isNull(Artikel.Schamotte_Prozent),"",CONCAT(Artikel.Schamotte_Prozent,"%")),
            " ",
            IF(isNull(Artikel.Schamotte_mm),"",CONCAT(Artikel.Schamotte_mm,"mm"))
            )
            AS Zusatzinformationen,

         Warengruppen.kasse_wgid,
         kasse_mwst.MwStSatz,
         Artikel.Artikelgruppe_alt AS AnwendungsTipp,
         Warengruppen.Warengruppe,
         kasse_warengruppen.Warengruppe AS KasseWarengruppe
        From Artikel
        LEFT JOIN Warengruppen ON Artikel.WgID=Warengruppen.WGID
        LEFT JOIN kasse_mwst on Artikel.MwSt = kasse_mwst.MwStID
        LEFT JOIN kasse_warengruppen on Warengruppen.kasse_wgid= kasse_warengruppen.id

        Where Artikel.'.$by.'=\''.$value.'\'';
        //$Sql = 'Select * From artikel Where ArtNr="r2505"';
        //return 'TEST'.$Sql;
        //if(strlen(trim($by))==0 || strlen(trim($value))==0) return false;
        $a = DB::fetcharray($Sql);

        if($a == false) return false;
        if(count($a)==1)
        {
            $a[0]['vk_preise'] = ArtikelStammDB::getArtikelPreise($a[0]['ArtNr']);
            return $a[0];
        }
        else
        {
            return false;
        }
        return false;
    }
    function getArtikelPreis($ArtNr='',$ab=1,$ehvk=1,$p_typ=1)
    {
        /*
         id	PreisTyp
         0	VK Brutto
         1	VK Direkt Brutto
         2	EK Netto
         */
        $ab = intval($ab);
        $ehvk = floatval(str_replace(',','.',$ehvk));
        $p_typ = intval($p_typ);

        //$Sql = 'Select * From ArtikelPreise Where ab=\''.$ab.'\' AND ehvk=\''.$ehvk.'\' AND P_typ=\''.$p_typ.'\'   AND ArtNr=\''.$ArtNr.'\'   ';
        $Sql = 'Select * From ArtikelPreise Where ab='.$ab.' AND ehvk='.$ehvk.' AND P_typ='.$p_typ.' AND ArtNr=\''.$ArtNr.'\'      ';
        //return 'TEST'.$Sql;
        //if(strlen(trim($by))==0 || strlen(trim($value))==0) return false;
        $a = DB::fetcharray($Sql);

        if(count($a)==1)
        {
            return $a[0];
        }
        else
        {
            return false;
        }

    }
    public function getArtikelPreise($ArtNr='',$PTyp=0)
    {
        // $PTyp 0 = VK brutto , 1 = EK netto, 2 = Direkt VK preise von Händler


        $sql = 'Select * From ArtikelPreise WHERE ArtNr="'.$ArtNr.'" AND P_typ='.$PTyp.' Order BY ab ASC';

        $p = DB::fetcharray($sql);

        return $p;

    }
    public function getArtikelPreisbyScan($barcode='')
    {

        if($barcode=='') return false;

        $sql = 'select ArtikelPreise.*, Artikel.Mass AS Mengeneinheit, Artikel.ArtikelBezeichnung
        from ArtikelPreise
        JOIN Artikel ON Artikel.ArtNr=ArtikelPreise.ArtNr
        where ArtikelPreise.ean="'.$barcode.'"';
        $p = DB::fetcharray($sql);
        if($p == false)
        {
            return false;
        }
        else
        {
            return $p[0];
        }


    }
    public function SearchProduct($string='')
    {
        if(empty($string)) return false;
        $searchtextarray = @explode(' ',$string);

    	$sql_search = '';

    	foreach($searchtextarray as $value)
    	{
    		$searchtextarray_new[]=str_replace('"','',$value);
    	}
    	unset($searchtextarray);
    	$searchtextarray = $searchtextarray_new;


    	$searchtext = str_replace('"','',implode(' ',$searchtextarray));

    	// Sonderzeichen abfangen
    	$v=array('ß');
    	$z=array('ss');
      	// one string search
      	$searchtextarray_from_one_string[] = $searchtext;
    	$searchtextarray_from_one_string[] = str_replace($v,$z,$searchtext);
    	// Sonderzeichen abfangen
    	$v=array('ss');
    	$z=array('ß');
      	// one string search
    	$searchtextarray_from_one_string[] = str_replace($v,$z,$searchtext);

      	$tmp = array_unique($searchtextarray_from_one_string);
      	unset($searchtextarray_from_one_string );
      	foreach($tmp as $value)
      	{
      		$searchtextarray_from_one_string[] = $value;
      	}

    	// Eingrenzung Temperatur
/*
    	if(intval($_SESSION['visit']['filter_temp_bis'])==0)
    	{
    		$_SESSION['visit']['filter_temp_bis'] = 9999999;
    	}
*/
    	// sql zusatz bei suche:
    	if(count($searchtextarray) >=1)
    	{

        $sql_search1 = '';



      		// Such-String one string:
      		$sql_search1 =' AND (';
      		//maximal 4 suchbegriffe auch wenn $searchtextarray > 4 elemente
      		$i = 0;
      		foreach($searchtextarray_from_one_string as $key => $value)
      		{
      			//echo $searchtextarray[$i];
      			$sql_search1.= '
      			Artikel.ArtNr 					LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Artikel.ArtikelBezeichnung 	LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Artikel.Artikeltext 			LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Artikel.Artikelgruppe 		LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Warengruppen.Warengruppe 	LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Warengruppen.warengruppe_text LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Artikel.Artikelgruppe_alt 	LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			OR Artikel.interne_info 	LIKE "%'.$searchtextarray_from_one_string[$i].'%"
      			';
      			$i++;
      			if($i < count($searchtextarray_from_one_string))
      			{
      			$sql_search1.= ' OR ';
      			}
      		}
      		$sql_search1.=' ) ';
      		// ende suchstring one string

      		// Such-String explodiert:
      		$sql_search2 =' AND (';
      		//maximal 4 suchbegriffe auch wenn $searchtextarray > 4 elemente
      		$i = 0;
      		foreach($searchtextarray as $key => $value)
      		{
      			//echo $searchtextarray[$i];
      			$sql_search2.= '
      			Artikel.ArtNr 					LIKE "%'.$searchtextarray[$i].'%"
      			OR Artikel.ArtikelBezeichnung 	LIKE "%'.$searchtextarray[$i].'%"
      			OR Artikel.Artikeltext 			LIKE "%'.$searchtextarray[$i].'%"
      			OR Artikel.Artikelgruppe 		LIKE "%'.$searchtextarray[$i].'%"
      			OR Warengruppen.Warengruppe 	LIKE "%'.$searchtextarray[$i].'%"
      			OR Warengruppen.warengruppe_text LIKE "%'.$searchtextarray[$i].'%"
      			OR Artikel.Artikelgruppe_alt 	LIKE "%'.$searchtextarray[$i].'%"
      			OR Artikel.interne_info 	LIKE "%'.$searchtextarray[$i].'%"
      			';
      			$i++;
      			if($i < count($searchtextarray))
      			{
      			$sql_search2.= ' OR ';
      			}
      		}
      		$sql_search2.=' ) ';
      		// ende suchstring explodiert

    		$sql = '
    		SELECT
    		Artikel.Artikelgruppe	AS	artikel_ag	,
    		Artikel.ArtikelBezeichnung	AS	artikel_bez	,
    		Artikel.Gesperrt	AS	artikel_gesperrt	,
    		Artikel.Einheit_Verkauf	AS	artikel_ehvk	,
    		Artikel.Fussnoten	AS	artikel_fussnoten	,
    		Artikel.AGID	AS	artikel_gewichtsfaktor	,
    		Artikel.ArtID	AS	artikel_id	,
    		LOWER(Artikel.Mass)	AS	artikel_mass	,
    		Artikel.Max_Temp	AS	artikel_max_temp_f	,
    		Artikel.Max_Temp	AS	artikel_max_temp	,
    		Artikel.MengenR	AS	artikel_mr	,
    		Artikel.MwSt	AS	artikel_mwst	,
    		Artikel.Neu	AS	artikel_neu	,
    		Artikel.ArtNr	AS	artikel_nr	,
        	Artikel.Schamotte_mm 	AS	artikel_schamotte_mm	,
    		Artikel.Schamotte_Prozent	AS	artikel_schamotte_p	,
    		Artikel.Sonderangebot	AS	artikel_sonderangebot	,
    		Artikel.Artikeltext	AS	artikel_text	,
    		trim(Artikel.Artikelgruppe_alt)	AS	artikel_tipp	,
    		Artikel.WgID	AS	artikel_wg,
    		Warengruppen.WGID				AS	warengruppe_id,
    		Warengruppen.Warengruppe		AS	warengruppe_bez	,
    		Warengruppen.warengruppe_bild	AS	warengruppe_bild	,
    		Warengruppen.warengruppe_text	AS	warengruppe_text	,
    		Warengruppen.rabattregel		AS	warengruppe_rabatt

    		FROM Artikel
    		LEFT JOIN Warengruppen on Artikel.WgID = Warengruppen.WGID
    		WHERE
    		Artikel.Gesperrt in ("a","h","x")
    		###sql_search###
    		ORDER BY warengruppe_bez, Artikel.Artikelgruppe
    		';

//
    		$sql = '
    		SELECT
    		Artikel.*,

            CONCAT
            (
            IF(isNull(Artikel.Max_Temp),"",CONCAT(Artikel.Max_Temp,"°C")),
            " ",
            IF(isNull(Artikel.Fussnoten),"",CONCAT("",Artikel.Fussnoten)),
            " ",
            IF(isNull(Artikel.Schamotte_Prozent),"",CONCAT(Artikel.Schamotte_Prozent,"%")),
            " ",
            IF(isNull(Artikel.Schamotte_mm),"",CONCAT(Artikel.Schamotte_mm,"mm"))
            )
            AS Zusatzinformationen,
            Artikel.Artikelgruppe_alt AS AnwendungsTipp,
    		Warengruppen.*

    		FROM Artikel
    		LEFT JOIN Warengruppen on Artikel.WgID = Warengruppen.WGID
    		WHERE
    		Artikel.Gesperrt in ("a","h","x")
    		###sql_search###
    		ORDER BY Artikel.gesperrt, Warengruppen.Warengruppe, Artikel.Artikelgruppe
    		';


    		$sql1 = str_replace('###sql_search###',$sql_search1, $sql);
    		$sql2 = str_replace('###sql_search###',$sql_search2,$sql);


            //echo $sql1;

    		// Datenbank abfragen:
    		$result		 	= DB::fetcharray($sql1);

            if($result == false)
            {
                return 'Nothing Found';
            }

            foreach($result as $row)
    		{
    			$ergebnisarray[] = $row;
    		}
    		if(count($ergebnisarray)==0)
    		{
    			// Datenbank abfragen:
    			$result	= DB::fetcharray($sql2);
    			foreach($result as $row)
    			{
    			    $ergebnisarray[] = $row;
    			}
    		}

    		//while($row = mysql_fetch_array($result, MYSQL_ASSOC))
    		if(is_array($ergebnisarray))
    		{
                foreach($ergebnisarray as $row)
                {
                    $ret_products[$row['WGID']]   ['Warengruppe'] = $row['Warengruppe'];
                    $ret_products[$row['WGID']]   ['products'] [$row['ArtNr']]  =  $row;

                    //$ret_products[$row['WGID']]   ['products'] [$row['ArtNr']]  =  $row;






                    //$ret_products[$row['artikel_nr']]=$row;

                    /*
                              $ret_products[$row['artikel_nr']]['artikel_schamotte_mm'] = artikel_schamotte_mm($row['artikel_schamotte_mm']);
                              $ret_products[$row['artikel_nr']]['artikel_schamotte_p'] = artikel_schamotte_p($row['artikel_schamotte_p']);
                              $ret_products[$row['artikel_nr']]['artikel_max_temp_f'] = artikel_max_temp_f($row['artikel_max_temp_f']);



                    $temp = explode('-',$row['artikel_max_temp']);

                    if(intval(@$temp[0]) > @intval(@$temp[1])) { @$temp[1] = @$temp[0]; @$temp[0] = 0;}

                    $ret_products[$row['artikel_nr']]['temp_von'] = intval(@$temp[0]);
                    $ret_products[$row['artikel_nr']]['temp_bis'] = intval(@$temp[1]);

                    $ret['temp_chooser']['temp_von'][$ret_products[$row['artikel_nr']]['temp_von']] = 1;
                    $ret['temp_chooser']['temp_bis'][$ret_products[$row['artikel_nr']]['temp_bis']] = 1;
                    */
                }
    		}





    		return $ret_products;



    	}
    }
    public function SearchKunden($string='')
    {
        $sql ='select * From Kunden where

        kundennummer LIKE "%'.$string.'%"
        OR
        Vorname LIKE "%'.$string.'%"
        OR
        Name LIKE "%'.$string.'%"
        OR
        Ansprechperson LIKE "%'.$string.'%"
        OR
        Strasse LIKE "%'.$string.'%"
        OR
        PLZ LIKE "%'.$string.'%"
        OR
        Ort LIKE "%'.$string.'%"
        OR
        Tel LIKE "%'.$string.'%"
        OR

        L_Vorname LIKE "%'.$string.'%"
        OR
        L_Name LIKE "%'.$string.'%"
        OR
        L_Ansprechperson LIKE "%'.$string.'%"
        OR
        L_Strasse LIKE "%'.$string.'%"
        OR
        L_PLZ LIKE "%'.$string.'%"
        OR
        L_Ort LIKE "%'.$string.'%"
        OR
        L_Tel LIKE "%'.$string.'%"

        OR
        Email LIKE "%'.$string.'%"
        OR
        Info_Kunde LIKE "%'.$string.'%"

        ORDER BY Kunden.Name

        ';
        $result		 	= DB::fetcharray($sql);
        return $result;

    }
    public function getKunde($kundennummer=0)
    {
        $Sql = 'Select * FROM Kunden
        Where kundennummer='.$kundennummer;
        $a = DB::fetcharray($Sql);

        if($a == false) return false;
        if(count($a)==1)
        {
            return $a[0];
        }
        else
        {
            return false;
        }
        return false;
    }
}
?>