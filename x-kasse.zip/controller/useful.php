<?php
class useful
{
    function addSpaces($int=1)
    {
        $ret='';
        for ($i = 1; $i <= $int; $i++)
        {
            $ret.=' ';
        }
        return $ret;
    }
    public function ArrayToJustifiedString($rawarray=array(),$maxlen=40,$force_cut=0)
    {
        // Versuche, mehrere Werte in Blocksatz auszugeben auf 40 zeichen Breite
        foreach($rawarray as $value)
        {
            $array[] = trim($value);
        }
        if(count($array)<=1)
        {
            return @implode($array,'');
        }

        $detectedTotal = 0;//count($array)-1; // Leerzeichen im Sinn = 2

        foreach($array as $element)
        {
            $detectedTotal= $detectedTotal + strlen(trim($element));
        }
        // $detectedTotal = 32

        $SpacesEachNum = floor(($maxlen - $detectedTotal) / (count($array)-1));
        // &nbsp;
        // \x20
        $ret = @implode($array,useful::addSpaces($SpacesEachNum));
        // ggf einen dazurechnen
        if(strlen($ret)<$maxlen)
        {
            // muss dazwischengequetscht werden:
            $array[0].=useful::addSpaces($maxlen-strlen($ret));
        }
        $ret = @implode($array,useful::addSpaces($SpacesEachNum));
        //strlen($ret).' '.

        if($force_cut==1)
        {
            if(strlen($ret)>$maxlen)
            {
                return substr($ret,0,$maxlen);
            }
            else
            {
                return $ret;
            }
        }
        else
        {
            return $ret;//.' z:'.$maxlen.' dt:'.$detectedTotal.' sp:'.$SpacesEachNum.' e:'.strlen($ret);
        }





    }
    public function showArrayAsTable($a,$addClass='',$id='')
    {
        $key = @array_keys($a);
        $summen = array();

        if(!is_array($a)) return false;

        if(count($a)<1) return '';

        //************************************ Head
        $ret = '<table '.$id.' class="AutoCreated '.$addClass.'"><thead><tr>';

        $i=0;
        foreach($a[ $key[0]] as $key => $v)
        {
            $ret.= '<th>'.$key.'</th>';
            $summen[$key] = 0;
            $i++;
        }
        $ret.='</tr></thead>';
        //********************************************
        // Footer


        foreach($a as $v)
        {

            $ret.= '<tr class="'.@$v['status'].'"><td>'.@implode('</td><td>',$v).'</td></tr>';
            foreach($v as $key => $value)
            {
                if(is_numeric($value))
                {
                    $summen[$key] = $summen[$key] + $value;
                }

            }
        }

      //  $ret.= '<tfoot><tr><td>'.@implode('</td><td>',$summen).'</td></tr></tfoot>';

        $ret.='</table>';
        return $ret;
    }
    public function searchdir ( $path , $maxdepth = -1 , $mode = "FULL" , $d = 0 )
    {
       if ( substr ( $path , strlen ( $path ) - 1 ) != '/' ) { $path .= '/' ; }

       $dirlist = array () ; // hier kommt alles rein !!!

       if ( $mode != "FILES" )
       {
       	$dirlist[] = $path ;
       }

       if ( $handle = opendir ( $path ) )
       {
           while ( false !== ( $file = readdir ( $handle ) ) )
           {
           		// Schleife startet - wenn Ding gefunden:
               if ( $file != '.' && $file != '..' )
               {
                   $filep = $path . $file ;		//pfad mit dateiname
                   if ( ! is_dir ( $filep ) ) 	//wenn dies kein Verzeichnis ist:
                   {
    	               	if ( $mode != "DIRS" )  // und der Modus auf FILE liegt...
    	               	{
    	               		$dateiendung = explode('.',$file);
    	               		$dirlist[] = array('dateiname' => $file, 'lastchange' => filemtime($filep), 'dateigroesse' => filesize($filep), 'dateiendung' => $dateiendung[1]);// wird das gefundene ins array gepackt
    	               	}
                   }
                   elseif ( $d >=0 && ($d < $maxdepth || $maxdepth < 0) )
                   {
                       $result = searchdir ( $filep . '/' , $maxdepth , $mode , $d + 1 ) ;
                       $dirlist = array_merge ( $dirlist , $result ) ;
                   }
    	       }
           }
           closedir ( $handle ) ;
       }
       //if ( $d == 0 ) { natcasesort ( $dirlist ) ; }
       return ( $dirlist ) ;
    }
    public function ReadTemplateAndReplace($path='',$tags_contents=array(),$tooneline=0,$array_of_constants=array())
    {
        if(is_file($path))
        {
            $tpl = file_get_contents($path);

            foreach($array_of_constants as $key => $value)
            {
                $tags_contents[$key]  = $value;
            }

            foreach($tags_contents as $mark => $value)
            {
                if(is_array($mark))
                {

                    //$tpl = str_replace('##'.$mark.'##',$value,$tpl);
                }
                else
                {
                    if(is_array($value))
                    {
                        $tpl = str_replace('##'.$mark.'##',print_r($value,true),$tpl);
                    }
                    else
                    {
                        $tpl = str_replace('##'.$mark.'##',$value,$tpl);
                    }

                    //echo 'Fehler in Funktion ReadTemplateAndReplace: $mark oder $value sind ein array()';
                }
            }


            return $tpl;
        }
        else
        {
            return $path.' TPL not found';
        }
    }
    public function array2xml($array=array())
    {
        $xml='<?xml version="1.0"  encoding="UTF-8" ?> '."\n<response>";
        if(is_array($array))
        {
            foreach($array as $key => $value)
            {
                if(is_numeric($value))
                {
                   $xml.= '<'.$key.'>'.$value.'</'.$key.'>'."\n";
                }
                else
                {
                    if(!is_array($value))
                    {
                        $xml.= '<'.$key.'><![CDATA['.$value.']]></'.$key.'>'."\n";
                    }

                }
            }
        }
        $xml.='</response>';
        return $xml;
    }
    public function to_clean_path($name)
    {
    	$name=str_replace(' ','-',$name);
      $erlaubt='-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.';
      $out='';
      $v1=array('ß', 'ö', 'Ö', 'ä', 'Ä', 'ü', 'Ü', '&');
      $z1=array('ss','oe','Oe','ae','Ae','ue','Ue','und');

      $v=$v1;
      $z=$z1;
      foreach ($v1 as $x)
      {
      	$v[] = utf8_encode($x);
      }
      foreach ($z1 as $x)
      {
      	$z[] = $x;
      }
      $name=str_replace($v,$z,$name);
      for ($i=0;$i<strlen($name);$i++) {
        if (strpos($erlaubt,$name[$i])===false) {} else {
          $out.=$name[$i];
        }
      }

        $out = str_replace('--','-',$out);
      return strtolower($out);
    }
    public function draw_pulldown(
        $selectname,
        $thisval,
        $value_show_array,
        $styles='',
        $start_item,
        $use_keys_as_values=0)
    {

        $tmp = @explode('[',$selectname);
        if(count($tmp>0))
        {
            $selectId = $tmp[0].'_'.str_replace(']','',$tmp[1]);
        }
        else
        {
            $selectId = $selectname;
        }

        $thisval=trim($thisval);

    	$ret ='<select name="'.$selectname.'" id="'.$selectId.'" '.$styles.'>'."\n";
    	$i=0;
    	if(is_array($start_item) )
    	{
            if(empty($thisval) || $thisval==0)
            {
                $sel = ' selected ';
            }
            else
            {
                $sel = '';
            }
    		$ret.='<!--start_item--><option value="'.$start_item[0].'" '.$sel.'>'.$start_item[1].'</option>'."\n";
    	}
    	if(is_array($value_show_array))
    	{
            foreach($value_show_array as $key => $value)
            {
                //if(!in_array($key,$hide_this_keys))
                //{
                    if($thisval == $key) {$sel ='selected'; } else { $sel ='';}
                    if($use_keys_as_values==1) {$ss=$key;} else {$ss = $value;}
                    $ret.='<option value="'.$key.'" '.$sel.'>'.$ss.'</option>'."\n";
                    $i++;
                //}
            }
    	}

    	$ret.='</select>'."\n";
    	return $ret;
    }
    function write_file($filename,$content)
    {
        $ret_meld = 1;

        	// wenn Datei nicht existiert, anlegen
        	if (!file_exists($filename))
        	{
        	  touch($filename);
        	}

        	if (is_writable($filename))
        	{
        	   if (!$handle = fopen($filename, "w"))
        	   {
        	       $ret_meld.=  'Kann die Datei '.$filename.' nicht öffnen';
        	       exit;
        	   }
        	   if (!fwrite($handle, $content))
        	   {
        	       $ret_meld.=  'Kann die Datei '.$filename.' nicht schreiben';
        	       exit;
        	   }

        	   fclose($handle);

        	}
        	else
        	{
        	   $ret_meld.=  "Die Datei '.$filename.' ist nicht schreibbar";
        	}

        	return $ret_meld;
    }
}

?>