<?php
class kasse_admin
{
    public function drawKasseAdmin()
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }

        $ret = array();

        $import_warengruppen_path = dirname(__FILE__).'/../import/warengruppen.txt';
        $import_mwst_path = dirname(__FILE__).'/../import/mwst.txt';

        $warengruppen = kasse::GetWarengruppen();
        $benutzer = kasse_admin::GetBenutzer();
        $mwst = kasse::GetMwSt();

        $i=0;
        foreach($benutzer as $key=>$value)
        {
            $benutzer_html[$i] =$value;
            unset($benutzer_html[$i]['Passwort']);
            if($value['Role']!='Admin')
            {
                $benutzer_html[$i]['Aktion'] = '<a href="Javascript:SwitchBenutzerStatus('.$value['ID'].');">Reset</a>';
            }
            $i++;
        }

        $ret[] = 'Es sind '.count($mwst).' MwSt Sätze installiert';
        $ret[] = useful::showArrayAsTable($mwst);
        $ret[] = 'Neu Importieren aus '.$import_mwst_path.'? <h2><a href="Javascript:ImportMwSt();">Jetzt ausführen</a></h2>';


        //print_r($warengruppen);

        $ret[] = 'Es sind '.count($warengruppen).' Warengruppen installiert';
        $ret[] = useful::showArrayAsTable($warengruppen);

        $wg_import = useful::ReadTemplateAndReplace($import_warengruppen_path,array(),0,array());
        $wg_import_array = kasse_admin::import_warengruppen_start($wg_import);

        $ret[] = count($wg_import_array).' Warengruppen aus '.$import_warengruppen_path.' neu importieren ?';
        $ret[] = '<h2><a href="Javascript:ImportWarengruppen();">Jetzt ausführen</a></h2>';


        $ret[] = 'Warengruppen Übersicht';
        $ret[] = useful::showArrayAsTable(kasse::GetWarengruppenCheck(),'tablesort');





        $ret[] = 'Es sind '.count($benutzer).' Benutzer installiert';
        $ret[] = '<div class="AdminBenutzerListe">';
        $ret[] = useful::showArrayAsTable($benutzer_html);
        $ret[] = '</div>';

        $ret[] = useful::ReadTemplateAndReplace('templates/admin/dialog/admin_benutzer.html',array(),0,array());




        return '<p>'.@implode('</p><p>',$ret).'</p>';
    }
    public function doAdminInsertBediener()
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Fehler '.print_r($_REQUEST,true);

        if(empty($_REQUEST['Passwort']) || empty($_REQUEST['BenutzerName']))
        {
            return $ret;
        }

        $_REQUEST['BenutzerKurz'] = strtoupper(strip_tags(trim($_REQUEST['BenutzerKurz'])));
        $_REQUEST['Passwort'] = md5($_REQUEST['Passwort']);

        $ret['message'] = 'Fehler '.print_r($_REQUEST,true);

        if(empty($_REQUEST['BenutzerKurz']) || strlen($_REQUEST['BenutzerKurz']) !=2)
        {
            return $ret;
        }

        $sql = 'select * from kasse_benutzer where BenutzerKurz="'.$_REQUEST['BenutzerKurz'].'"';
        $list = DB::fetcharray($sql);
        if($list[0]['BenutzerKurz']==$_REQUEST['BenutzerKurz'])
        {
            return $ret;
        }

        $sql ='INSERT INTO kasse_benutzer (BenutzerKurz,BenutzerName,Role,Passwort) VALUES (

        "'.$_REQUEST['BenutzerKurz'].'",
        "'.$_REQUEST['BenutzerName'].'",
        "'.$_REQUEST['Role'].'",
        "'.$_REQUEST['Passwort'].'"

        )';

        $insert = DB::insert($sql);
        $ret['success'] = 1;

        $ret['message'] = 'Fehler: '.print_r($_REQUEST,true);

        kasse::kasse_log('ADMIN','Neuen Bediener erstellt:'.print_r($_REQUEST,true));


        $ret['success'] = 1;
        return $ret;

    }
    public function GetBenutzer()
    {
        $sql = 'select * from kasse_benutzer';
        $list = DB::fetcharray($sql);
        if($list==false || count($list)==0)
        {
            return false;
        }
        return $list;
    }
    public function drawWarengruppen()
    {
        $wg = kasse::GetWarengruppen();
        return print_r($wg,true);
    }
    function doImportWarengruppen()
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        //$a = import_warengruppen_start(dirname(__FILE__).'/../import/warengruppen.txt');
        $a = kasse_admin::import_warengruppen_start(useful::ReadTemplateAndReplace(dirname(__FILE__).'/../import/warengruppen.txt',array(),0,array()));

        $old = kasse::GetWarengruppen();

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error';

        if(count($a)<2) return $ret;

        $ret['success'] = 1;
        $ret['message'] = 'OK '.count($a);

        foreach($a as $wg)
        {
            $sql= 'INSERT INTO kasse_Warengruppen (id,Warengruppe,Sortierung,MwStID,DialogPrefix) ';

            $sql.=' VALUES (';
            $sql.='"'.$wg['id'].'",';
            $sql.='"'.$wg['Warengruppe'].'",';
            $sql.='"'.$wg['Sortierung'].'",';
            $sql.='"'.$wg['MwStID'].'",';
            $sql.='"'.$wg['DialogPrefix'].'"';
            $sql.=')';

            DB::insert($sql);
        }

        kasse::kasse_log('ADMIN','Warengruppen Importiert. OLD:'.print_r($old,true));

        return $ret;
    }
    function doImportMwSt()
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        //$a = import_warengruppen_start(dirname(__FILE__).'/../import/warengruppen.txt');
        $a = kasse_admin::import_mwst_start(useful::ReadTemplateAndReplace(dirname(__FILE__).'/../import/mwst.txt',array(),0,array()));

        $old = kasse::GetMwSt();

        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Error';

        if(count($a)<2) return $ret;

        $ret['success'] = 1;
        $ret['message'] = 'OK '.count($a);

        foreach($a as $wg)
        {
            $sql= 'INSERT INTO kasse_mwst (MwStID,MwStSatz) ';

            $sql.=' VALUES (';
            $sql.='"'.$wg['MwStID'].'",';
            $sql.='"'.$wg['MwStSatz'].'"';
            $sql.=')';

            DB::insert($sql);
        }

        kasse::kasse_log('ADMIN','MwSt Importiert. OLD:'.print_r($old,true));

        return $ret;
    }
    function import_warengruppen_start($str)
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        $ret = array();

        $t = @explode("\n",$str);

        $i=1;
        foreach($t as $z)
        {
            if($i!=1)
            {
                $zt = @explode("\t",$z);

                $ret[$i]['id'] = $zt[0];
                $ret[$i]['Warengruppe'] = $zt[1];
                $ret[$i]['Sortierung'] = $zt[2];
                $ret[$i]['MwStID'] = $zt[3];
                $ret[$i]['DialogPrefix'] = @$zt[4];
            }
            $i++;
        }


        return $ret;
    }
    function import_mwst_start($str)
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        $ret = array();

        $t = @explode("\n",$str);

        $i=1;
        foreach($t as $z)
        {
            if($i!=1)
            {
                $zt = @explode("\t",$z);

                $ret[$i]['MwStID'] = $zt[0];
                $ret[$i]['MwStSatz'] = $zt[1];
            }
            $i++;
        }


        return $ret;
    }
    function doAdminSwitchBenutzerStatus()
    {
        if($_SESSION['kasse']['level']<3)
        {
            return '';
        }
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Switch User Error';

        if(intval($_REQUEST['UserId'])==0)
        {
            return $ret;
        }
        $user = kasse_user::isBenutzer($_REQUEST['UserId']);
        if($user==false)
        {
            $ret['message'] = 'user nicht gefunden';
            return $ret;
        }

        $sql = 'UPDATE kasse_benutzer set Passwort="'.RESETUSERPASSWORD.'" WHERE ID='.intval($_REQUEST['UserId']);
        $do = DB::update($sql);
        $ret['message'] = 'Passwort des Benutzers wurde erfolgreich zurückgesetzt';

        kasse::kasse_log('ADMIN','Passwort Reset:'.print_r($sql,true));

        return $ret;
    }
}
?>