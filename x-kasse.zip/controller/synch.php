<?php
class synch
{
    public function synchronisiere_zjournal()
    {
        $ret = array();
        $ret['success'] = 0;
        $ret['message'] = 'Synch nicht erfolgreich';

        // Kassen journal einlesen:

        $Sql="DELETE  from kasse_zjournal";
        ACCDB::delete($Sql);
        $Sql="DELETE  from kasse_zvorgaenge";
        ACCDB::delete($Sql);

        $Sql="Select * from kasse_zjournal ORDER BY ID";
        $a = DB::fetcharray($Sql);
        $b = ACCDB::fetcharray($Sql);
        if($a == false) return false;
        $ret['message'] = 'MYSQL:'.count($a).' ACCDB:'.count($b);
        foreach($a as $key => $journal)
        {
            if(!isset($b[$key]) )
            {
                $journal['UpdateDatetime'] = $journal['InsertDatetime'];
                $journal['UpdateByBenutzerKurz'] = $journal['InsertDatetime'];
                $journal['TakeAwayDate'] = $journal['InsertDatetime'];

                $sql = array();
                foreach($journal as $attr => $value)
                {
                    $sql['fields'][] = $attr;
                    if(is_numeric(str_replace('.','',$value)))
                    {
                        $value_friently = str_replace('.',',',$value);
                        $sql['values'][] = "'".str_replace('"','',$value_friently)."'";
                    }
                    else
                    {
                        $value_friently = $value;
                        $sql['values'][] = "'".str_replace('"','',$value_friently)."'";
                    }
                }
                $sql_do= 'INSERT INTO kasse_zjournal ('.@implode(',',$sql['fields']).') VALUES ('.@implode(',',$sql['values']).')';
                //$sql_do= 'INSERT INTO kasse_zjournal (ArtNr,VorgangID,ArtikelBezeichnung,CUR) VALUES (1,1,1,1)';
                $ret['message'].=$sql_do;
                $c = ACCDB::insert($sql_do);
            }
        }
        $Sql="Select * from kasse_zvorgaenge ORDER BY ID";
        $a = DB::fetcharray($Sql);
        $b = ACCDB::fetcharray($Sql);
        if($a == false) return false;
        $ret['message'] = 'MYSQL:'.count($a).' ACCDB:'.count($b);
        foreach($a as $key => $journal)
        {
            if(!isset($b[$key]) )
            {
                $journal['BonGedrucktDatetime'] = $journal['AbschlussDatetime'];
                //$journal['UpdateByBenutzerKurz'] = $journal['InsertDatetime'];
                //$journal['TakeAwayDate'] = $journal['InsertDatetime'];

                $sql = array();
                foreach($journal as $attr => $value)
                {
                    $sql['fields'][] = $attr;
                    if(is_numeric(str_replace('.','',$value)))
                    {
                        $value_friently = str_replace('.',',',$value);
                        $sql['values'][] = "'".str_replace('"','',$value_friently)."'";
                    }
                    else
                    {
                        $value_friently = $value;
                        $sql['values'][] = "'".str_replace('"','',$value_friently)."'";
                    }
                }
                $sql_do= 'INSERT INTO kasse_zvorgaenge ('.@implode(',',$sql['fields']).') VALUES ('.@implode(',',$sql['values']).')';
                //$sql_do= 'INSERT INTO kasse_zjournal (ArtNr,VorgangID,ArtikelBezeichnung,CUR) VALUES (1,1,1,1)';
                $ret['message'].=$sql_do;
                $c = ACCDB::insert($sql_do);
            }
        }



//

        /*  1) delete artikel, artikelpreise
            2) Select/Insert Artikel from ACCDB
            3) Select/Insert ArtikelPreise from Accdb
         *
         *
         *
         * Select/Insert  from local zjournal to accdb::zjournal
         *
         *
         *
         * */


        $ret['message']= 'Fertig';



        return $ret;
    }
}
/*
 *
 *         $KASSE_DBSERVER = KASSE_DBSERVER;
         $KASSE_DB=KASSE_DB;
         $KASSE_DBUSERNAME = KASSE_DBUSERNAME;

        //use Ifsnop\Mysqldump as IMysqldump;

        $settings = array(
            'exclude-tables' => array('kasse_benutzer','kasse_log','kasse_mwst','kasse_zberichte','kasse_journal','kasse_vorgaenge','kasse_warengruppen','kasse_zvorgaenge'),


            'add-drop-table' => false,
            'single-transaction' => true,
            'lock-tables' => true,
            'add-locks' => true,
            'extended-insert' => false,
            'disable-keys' => true,
            'skip-triggers' => false,
            'add-drop-trigger' => true,
            'routines' => true,
            'databases' => false,
            'add-drop-database' => false,
            'hex-blob' => true,
            'no-create-info' => true,
            'where' => ''
            );


        try {
            $dump = new Ifsnop\Mysqldump\Mysqldump(
                "mysql:host=$KASSE_DBSERVER;dbname=$KASSE_DB",
                $KASSE_DBUSERNAME,
                '',
                $settings
            );
            $dump->start(dirname(__FILE__).'/X_SqlDump'.date("D").'.sql');
            $ret['success'] = 1;
            $ret['message'] = 'Datensicherung fertig';
            return $ret;
        } catch (\Exception $e) {
            $ret['message'] = 'mysqldump-php error: ' . $e->getMessage();
            return $ret;

        }*/
?>
