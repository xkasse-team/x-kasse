<?php
session_start();

if(!file_exists('config/config.php'))
{
    die("<a href='install/install.php'>Installation nicht gefunden</a>");
}
else
{
    require_once('config/config.php');
}
require_once('controller_db/kabimba.db.class.php');
require_once('controller/ArtikelStamm.db.php');
require_once('controller/useful.php');
require_once('controller/kasse_user.php');
require_once('controller/kasse.php');
require_once('controller/kasse_dialog.php');
require_once('controller/kasse_admin.php');

require_once('libraries_3rdparty/mysqldump-php-master/src/Ifsnop/Mysqldump/Mysqldump.php');

DB::init(KASSE_DBSERVER,KASSE_DBUSERNAME,KASSE_DBPASSWORD,KASSE_DB);

echo kasse::draw_kasse();


?>