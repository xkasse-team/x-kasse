<?php
define('VV_DBSERVER','localhost');
define('VV_DBUSERNAME','');
define('VV_DBPASSWORD','');
define('VV_DB_DSN','my_db_dsn');
define('VV_DBPATH','w:/my_db.accdb');
define('VV_IMAGES_PATH','w:/bilder');

ACCDB::init(VV_DBPATH,VV_DB_DSN,VV_DBUSERNAME,VV_DBPASSWORD);

?>