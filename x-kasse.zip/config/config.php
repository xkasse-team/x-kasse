<?php
// Übernahme der Werte bei Installation
define('KASSEID','01');
define('KASSEBEZEICHNUNG','testkasse Björn');
define('KASSEABLAGE','C:/mohr4u/pub/toepferspass_app/kasse_ablage/'); //für Z-Berichte und Prüfungen
define('KASSEBACKUP','C:/mohr4u/pub/toepferspass_app/kasse_backup/'); //für SQL Dumps
define('ARTNR_DEFAULT','9999');
define('PRODUCT_IMAGES_BE','../bilder/'); // ../bilder/
define('PRODUCT_IMAGES_FE','../bilder/'); // ../bilder/
define('KASSE_DBSERVER','localhost');
define('KASSE_DBUSERNAME','root');
define('KASSE_DBPASSWORD','');
define('KASSE_DB','test');

// Bei Installation automatisch generierte Werte - besser nicht ändern:
define('BONPRINTER_USE',0);  // Kein Bon Drucker verwenden
define('KASSESERVERNAME','localhost'); //SERVER_NAME
define('CURRENCY','EUR');
define('CURRENCY_SYM','€');
define('RESETUSERPASSWORD','25d55ad283aa400af464c76d713c07ad'); // md5(12345678)
define('COUNTRY','GERMANY');
define('KASSE_BONPRINTER','EPSON TM-T88III Receipt');
define('KASSE_BONLOGOPATH','img/LogoBon.png');
define('BONMAXLENGTH',42);
define('KASSEROOT','C:/kasse/kasse/'); //SCRIPT_FILENAME
define('KASSEINSTALLDATETIME','2017-12-12 10:46:27');
define('VORGANG_ART_OFFENERVORGANG','OFFENER VORGANG');  //
define('VORGANG_ART_STORNO','STORNO');  //
define('VORGANG_ART_VERKAUF','VERKAUF');  //
define('VORGANG_ARTEN',array('VERKAUF','STORNO'));  // Nur diese werden für einen Abschluss akzeptiert
define('BELEGINFO_ARTEN',array('RETOUR','SOFORTSTORNO'));  // Nur diese werden für eine Hinzu-Transaktion akzeptiert
define('JOURNAL_UNDO','STORNO');  // Zusätzliche Information zu einem Z-Journal Datensatz bei Sofortstorno wegen Eingabefehler
define('KASSE_TABLENAMES',array('kasse_benutzer','kasse_log','kasse_mwst','kasse_zberichte','kasse_journal','kasse_vorgaenge','kasse_warengruppen','kasse_zjournal','kasse_zvorgaenge'));
define('BELEG_TITEL_PRINT', array(
    'VERKAUF'  => 'Bar Verkauf',
    'VERKAUF'  => 'Bar Verkauf',
    'STORNO' => 'Storno Beleg',
    'Offener Vorgang' => 'Offener Vorgang'
));
define('STORNO_GRUENDE', array('Falscher Zahlungs/Abschlussart','Fehlbedienung','Artikeltausch','Artikel Rückgabe'));
define('BONKOPIETEXT', '*** KOPIE ***');
?>