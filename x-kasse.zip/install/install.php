<?php
session_start();



require_once('../controller_db/kabimba.db.class.php');
require_once('../controller/ArtikelStamm.db.php');
require_once('../controller/useful.php');
require_once('../controller/kasse_user.php');
require_once('../controller/kasse.php');
require_once('../controller/kasse_dialog.php');
require_once('../controller/kasse_admin.php');
require_once('../controller/kasse_print.php');
require_once('../libraries_3rdparty/fpdf181/fpdf.php');




$er=array();
if(file_exists(dirname(__FILE__).'/../config/config.php'))
{
   $er[] = '<h1>config/config.php ist vorhanden!</h1><a href="../index.php">Weiter</a>';

    require_once(dirname(__FILE__).'/../config/config.php');
    DB::init(KASSE_DBSERVER,KASSE_DBUSERNAME,KASSE_DBPASSWORD,KASSE_DB);

    if(@$_REQUEST['do'] =='InstallSql')
    {
        $sql = useful::ReadTemplateAndReplace('install.sql',array(),0,array());

        $dothey = explode(';',$sql);

        foreach($dothey as $s)
        {
            $Install[] = DB::insert($s);
        }

        echo implode('<br>',$Install);
        
        die(" <br><a href='install.php'>Weiter</a>");
    }




    $sql = 'SHOW TABLES';
    $tables = DB::fetcharray($sql);
    $tables_exist = array();
    if(is_array($tables))
    {
        foreach($tables as $table)
        {
            $tables_exist[$table['Tables_in_'.KASSE_DB]] = $table['Tables_in_'.KASSE_DB];
        }
    }
    $block=0;
    foreach($tables_exist as $tablename)
    {
        if(in_array($tablename,KASSE_TABLENAMES))
        {
            $block++;
        }
    }

    if($block>0)
    {
        $er[] = '<h3>Installierte Tabellen:</h3>'.implode(', ',$tables_exist);
        $er[] = '<h3>Neu Anlegen erst nach Löschen der aktiven Tabellen möglich:</h3>'.@implode(', ',KASSE_TABLENAMES);
        
    }
    else
    {
        $er[] = '<h3>Datenbank OK, keine Kassen-Tabellen vorhanden</h3>';
        $er[] = '<h3><a href="install.php?do=InstallSql">Alle X-Kasse Tabellen anlegen</a></h3>';
    }





}
if(count($er)>0)
{
    echo implode('<br>',$er);
    //die('<hr>Installation abgebrochen');
}

// Installation:
if(isset($_REQUEST['i']))
{
    $_REQUEST['i']['KASSEINSTALLDATETIME'] = date("Y-m-d H:i:s");
    $_REQUEST['i']['KASSEROOT'] = str_replace('/install/install.php','/',$_SERVER['SCRIPT_FILENAME']);
    $_REQUEST['i']['KASSESERVERNAME'] = $_SERVER['SERVER_NAME'];

    foreach($_REQUEST['i'] as $key => $value)
    {
        if(empty($value))
        {
            die('<h3>Bitte alle Felder ausfüllen: '.$key.'</h3>');
        }
        $_REQUEST['i'][$key] = trim($value);
    }

    $old_config_file = useful::ReadTemplateAndReplace('../config/config.php',array(),0,array());
    $new_config_file = useful::ReadTemplateAndReplace('config.default.php',$_REQUEST['i'],0,array());

    $pdf = kasse_print::PrintSomethingToPdf('../config/Installation.pdf',$new_config_file);

    if($pdf==false)
    {
        die("<h1>Konnte keinen Installationsbericht anlegen: </h1> (Datei vorhanden?) ../config/Installation.pdf");
    }

    useful::write_file('../config/config.bak.'.date("YmdHis").'.php',$old_config_file);
    useful::write_file('../config/config.php',$new_config_file);

    header("location: install.php");


}



?>
<!doctype html>
<html lang="de">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>Kasse</title>


<link rel="icon" type="image/vnd.microsoft.icon" href="../img/favicon.ico">

<script src="../libraries_3rdparty/jquery/jquery-3.2.1.min.js"></script>

<link rel="stylesheet" href="../libraries_3rdparty/jquery-ui-1.12.1/jquery-ui.css">
<script src="../libraries_3rdparty/jquery-ui-1.12.1/jquery-ui.min.js"></script>



<link rel="stylesheet" href="../libraries_kasse/screensaver/screensaver.css">

<link rel="stylesheet" href="../css/kasse.styles.css">
<link rel="stylesheet" href="../css/warengruppen.css">

<script src="../libraries_3rdparty/jquery-Scanner-Detection-master/jquery.scannerdetection.js" type="text/javascript"></script>

<script type="text/javascript" src="../libraries_3rdparty/Mottie-tablesorter-08bf513/js/jquery.tablesorter.js"></script>
<script type="text/javascript" src="../libraries_3rdparty/Mottie-tablesorter-08bf513/js/jquery.tablesorter.widgets.js"></script>

<link rel="stylesheet" href="../libraries_3rdparty/lightbox2-master/dist/css/lightbox.min.css">

<!-- include all kasse javascript -->

<script src="../js/kasse_dialog.js" type="text/javascript"></script>
<script src="../js/kasse_user.js" type="text/javascript"></script>
<script src="../js/kasse_admin.js" type="text/javascript"></script>
<script src="../js/kasse.js" type="text/javascript"></script>




</head>
<body style="overflow: auto;height: 10000px;padding: 20px;">



<?php

    if(!file_exists(dirname(__FILE__).'/../config/config.php'))
    {

?>

<form action="install.php" method="post">
    <h1>Neu-Installation Kasse</h1>

<span class="sLabel">KASSE-ID:</span><input type="text" name="i[KASSEID]" value="01"> z.B. 01 <br>
<span class="sLabel">KASSEBEZEICHNUNG:</span><input type="text" name="i[KASSEBEZEICHNUNG]" value=""> z.B. Ladenkasse 1<br>
<span class="sLabel">KASSEABLAGE:</span><input type="text" name="i[KASSEABLAGE]" value="<?php echo $_SERVER['DOCUMENT_ROOT'];?>/kasse_ablage/">c:/Ordner\ Ablageort für PDF (Z-Berichte, Z-Journal)<br>
<span class="sLabel">KASSEBACKUP:</span><input type="text" name="i[KASSEBACKUP]" value="<?php echo $_SERVER['DOCUMENT_ROOT'];?>/kasse_backup/">c:/Ordner\ Ablageort für SQL-Dump<br>
<span class="sLabel">ARTNR_DEFAULT:</span><input type="text" name="i[ARTNR_DEFAULT]" value="9999"><br>
<span class="sLabel">PRODUCT_IMAGES_BE:</span><input type="text" name="i[PRODUCT_IMAGES_BE]" value="../bilder/"> relativ zur X-Kasse<br>
<span class="sLabel">PRODUCT_IMAGES_FE:</span><input type="text" name="i[PRODUCT_IMAGES_FE]" value="../bilder/"> relativ zur X-Kasse<br>
<span class="sLabel">KASSE_DBSERVER:</span> <input type="text" name="i[KASSE_DBSERVER]" value="localhost"><br>
<span class="sLabel">KASSE_DBUSERNAME:</span> <input type="text" name="i[KASSE_DBUSERNAME]" value="root"><br>
<span class="sLabel">KASSE_DBPASSWORD:</span> <input type="text" name="i[KASSE_DBPASSWORD]" value=" "><br>
<span class="sLabel">KASSE_DB:</span> <input type="text" name="i[KASSE_DB]" value="dbname"><br>

<input type="submit" class="ButtonUniform" style="margin: 10px; padding: 20px;" value="Installieren - config/config.php überschreiben">
</form>
<?php } ?>
</body>
</html>