<?php
// Übernahme der Werte bei Installation
define('KASSEID','##KASSEID##');
define('KASSEBEZEICHNUNG','##KASSEBEZEICHNUNG##');
define('KASSEABLAGE','##KASSEABLAGE##'); //für Z-Berichte und Prüfungen
define('KASSEBACKUP','##KASSEBACKUP##'); //für SQL Dumps
define('ARTNR_DEFAULT','##ARTNR_DEFAULT##');
define('PRODUCT_IMAGES_BE','##PRODUCT_IMAGES_BE##'); // ../bilder/
define('PRODUCT_IMAGES_FE','##PRODUCT_IMAGES_FE##'); // ../bilder/
define('KASSE_DBSERVER','##KASSE_DBSERVER##');
define('KASSE_DBUSERNAME','##KASSE_DBUSERNAME##');
define('KASSE_DBPASSWORD','##KASSE_DBPASSWORD##');
define('KASSE_DB','##KASSE_DB##');

// Bei Installation automatisch generierte Werte - besser nicht ändern:
define('BONPRINTER_USE',1);
define('KASSESERVERNAME','##KASSESERVERNAME##'); //SERVER_NAME
define('CURRENCY','EUR');
define('CURRENCY_SYM','€');
define('RESETUSERPASSWORD','25d55ad283aa400af464c76d713c07ad'); // md5(12345678)
define('COUNTRY','GERMANY');
define('KASSE_BONPRINTER','EPSON TM-T88III Receipt');
define('KASSE_BONLOGOPATH','img/LogoBon.png');
define('BONMAXLENGTH',42);
define('KASSEROOT','##KASSEROOT##'); //SCRIPT_FILENAME
define('KASSEINSTALLDATETIME','##KASSEINSTALLDATETIME##');
define('VORGANG_ART_OFFENERVORGANG','OFFENER VORGANG');  //
define('VORGANG_ART_STORNO','STORNO');  //
define('VORGANG_ART_VERKAUF','VERKAUF');  //
define('VORGANG_ARTEN',array('VERKAUF','STORNO'));  // Nur diese werden für einen Abschluss akzeptiert
define('BELEGINFO_ARTEN',array('RETOUR','SOFORTSTORNO'));  // Nur diese werden für eine Hinzu-Transaktion akzeptiert
define('JOURNAL_UNDO','STORNO');  // Zusätzliche Information zu einem Z-Journal Datensatz bei Sofortstorno wegen Eingabefehler
define('KASSE_TABLENAMES',array('kasse_benutzer','kasse_log','kasse_mwst','kasse_zberichte','kasse_journal','kasse_vorgaenge','kasse_warengruppen','kasse_zjournal','kasse_zvorgaenge'));
define('BELEG_TITEL_PRINT', array(
    'VERKAUF'  => 'Bar Verkauf',
    'VERKAUF'  => 'Bar Verkauf',
    'STORNO' => 'Storno Beleg',
    'Offener Vorgang' => 'Offener Vorgang'
));
define('STORNO_GRUENDE', array('Falscher Zahlungs/Abschlussart','Fehlbedienung','Artikeltausch','Artikel Rückgabe'));
define('BONKOPIETEXT', '*** KOPIE ***');
?>