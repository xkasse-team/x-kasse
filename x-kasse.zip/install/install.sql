

CREATE TABLE `kasse_benutzer` (
  `ID` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `BenutzerKurz` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BenutzerName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Passwort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Aktiv` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `kasse_benutzer` (`ID`, `BenutzerKurz`, `BenutzerName`, `Passwort`, `Role`, `Aktiv`) VALUES
(1, 'YY', 'Admin', '25d55ad283aa400af464c76d713c07ad', 'Admin', 1);


CREATE TABLE `kasse_journal` (
  `ID` int(11) NOT NULL,
  `BelegInfo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WarengruppenId` int(11) NOT NULL DEFAULT '0',
  `ArtNr` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VorgangID` int(11) NOT NULL,
  `ArtikelBezeichnung` text COLLATE utf8_unicode_ci NOT NULL,
  `Anzahl` double DEFAULT '0',
  `EpBrutto` double DEFAULT '0',
  `zSummeBrutto` double NOT NULL DEFAULT '0',
  `zSummeNetto` double NOT NULL DEFAULT '0',
  `zSummeMwSt` double NOT NULL DEFAULT '0',
  `CUR` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `Rabatt` double NOT NULL DEFAULT '0',
  `MwstProzent` double DEFAULT '0',
  `InsertDatetime` datetime DEFAULT NULL,
  `UpdateDatetime` datetime DEFAULT NULL,
  `InsertByBenutzerKurz` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateByBenutzerKurz` datetime DEFAULT NULL,
  `Menge` double DEFAULT NULL,
  `Mengeneinheit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BezugID` int(11) NOT NULL DEFAULT '0',
  `TakeAwayDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_log` (
  `id` int(11) NOT NULL,
  `InsertDatetime` datetime NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `info` text COLLATE utf8_unicode_ci NOT NULL,
  `BenutzerKurz` varchar(3) COLLATE utf8_unicode_ci  NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_mwst` (
  `MwStID` int(11) NOT NULL,
  `MwStSatz` double DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_vorgaenge` (
  `id` int(11) NOT NULL,
  `BenutzerID` int(11) DEFAULT '0',
  `InsertDatetime` datetime DEFAULT NULL,
  `UpdateDatetime` datetime NOT NULL,
  `Abschluss` int(1) NOT NULL DEFAULT '0',
  `AbschlussDatetime` datetime NOT NULL,
  `VorgangArt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KdNr` int(11) DEFAULT '0',
  `BenutzerKurz` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BonGedruckt` int(1) DEFAULT '0',
  `BonGedrucktDatetime` datetime DEFAULT NULL,
  `ZahlungsArt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Zid` int(11) NOT NULL DEFAULT '0',
  `Zflag` int(11) NOT NULL DEFAULT '0',
  `ControlSummeBrutto` double NOT NULL,
  `ControlSummeBar` double NOT NULL,
  `ControlECBeleg` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ControlBemerkung` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SystemInfo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `L_Anrede` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Vorname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Ansprechperson` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Strasse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_PLZ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Ort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Land` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Anrede` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Vorname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Ansprechperson` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Strasse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_PLZ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Ort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Land` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_warengruppen` (
  `id` int(11) NOT NULL,
  `Warengruppe` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MwStID` int(11) NOT NULL DEFAULT '0',
  `Sortierung` int(11) DEFAULT NULL,
  `DialogPrefix` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `RagattRegel` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_zberichte` (
  `id` int(11) NOT NULL,
  `InsertDatetime` datetime NOT NULL,
  `zBerichtgedruckt` int(1) NOT NULL DEFAULT '0',
  `BerichtTag` date NOT NULL,
  `BenutzerKurz` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ZData` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `kasse_zjournal` (
  `ID` int(11) NOT NULL,
  `BelegInfo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WarengruppenId` int(11) NOT NULL DEFAULT '0',
  `ArtNr` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VorgangID` int(11) NOT NULL,
  `ArtikelBezeichnung` text COLLATE utf8_unicode_ci NOT NULL,
  `Anzahl` double DEFAULT '0',
  `EpBrutto` double DEFAULT '0',
  `zSummeBrutto` double NOT NULL DEFAULT '0',
  `zSummeNetto` double NOT NULL DEFAULT '0',
  `zSummeMwSt` double NOT NULL DEFAULT '0',
  `CUR` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `Rabatt` double NOT NULL DEFAULT '0',
  `MwstProzent` double DEFAULT '0',
  `InsertDatetime` datetime DEFAULT NULL,
  `UpdateDatetime` datetime DEFAULT NULL,
  `InsertByBenutzerKurz` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateByBenutzerKurz` datetime DEFAULT NULL,
  `Menge` double DEFAULT NULL,
  `Mengeneinheit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BezugID` int(11) NOT NULL DEFAULT '0',
  `TakeAwayDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `kasse_zvorgaenge` (
  `id` int(11) NOT NULL,
  `BenutzerID` int(11) DEFAULT '0',
  `InsertDatetime` datetime DEFAULT NULL,
  `UpdateDatetime` datetime NOT NULL,
  `Abschluss` int(1) NOT NULL DEFAULT '0',
  `AbschlussDatetime` datetime NOT NULL,
  `VorgangArt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KdNr` int(11) DEFAULT '0',
  `BenutzerKurz` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BonGedruckt` int(1) DEFAULT '0',
  `BonGedrucktDatetime` datetime DEFAULT NULL,
  `ZahlungsArt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Zid` int(11) NOT NULL DEFAULT '0',
  `Zflag` int(11) NOT NULL DEFAULT '0',
  `ControlSummeBrutto` double NOT NULL,
  `ControlSummeBar` double NOT NULL,
  `ControlECBeleg` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ControlBemerkung` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SystemInfo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `L_Anrede` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Vorname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Ansprechperson` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Strasse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_PLZ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Ort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Land` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L_Tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Anrede` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Vorname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Ansprechperson` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Strasse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_PLZ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Ort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `R_Land` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


ALTER TABLE `kasse_journal`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `kasse_log`
  ADD PRIMARY KEY `id` (`id`);

ALTER TABLE `kasse_mwst`
  ADD PRIMARY KEY `MwStID` (`MwStID`);

ALTER TABLE `kasse_vorgaenge`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `kasse_warengruppen`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `kasse_zberichte`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `BerichtTag` (`BerichtTag`),
  ADD KEY `id` (`id`);



ALTER TABLE `kasse_zjournal`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `kasse_zvorgaenge`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `kasse_journal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_mwst`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_vorgaenge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_warengruppen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_zberichte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `kasse_zjournal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `kasse_zvorgaenge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
