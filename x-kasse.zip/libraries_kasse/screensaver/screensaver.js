var s_saver;

jQuery(document).ready(function($)
{
    $("body").prepend("<div id=\"screensaver\"><div><div><img src=\"img/Screensaver.png\"></div></div></div>");
});

$('body').mousemove(function()
{

    var timeout = 5; // Min

    clearTimeout(s_saver);

    s_saver = setTimeout(function(){
        $('#screensaver').fadeIn("slow");

        KasseLogOut();

    }, (60*1000*timeout));

    $('#screensaver').fadeOut(500);
});

