<?php

class ACCDB
{
    // Treiber notwendig: AccessDatabaseEngine.exe
    // https://www.microsoft.com/en-us/download/details.aspx?id=23734
    // http://php.net/manual/de/pdo.connections.php
    // https://code.tutsplus.com/tutorials/why-you-should-be-using-phps-pdo-for-database-access--net-12059

    public static $db = null;
    //public static $insertID;

    public static function init($dbName, $dsn='', $dbUser='', $dbPassword='')
    {
        try {
            self::$db = new PDO("odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBq=$dbName;charset=UTF-8;");
            self::$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e) {
            echo $e->getMessage()."\n";
            exit;
        }
        //self::$db->exec("SET NAMES utf8");
    }

    function insert($sql)
    {
        //echo $sql;
        $prepare = self::$db->prepare($sql);
        $prepare->execute();
        $insertID = ACCDB::fetcharray("SELECT @@IDENTITY AS insert_id");
        return intval($insertID[0]['insert_id']);
    }

    function fetcharray($sql)
    {
        //echo $sql;

        try {
         $result = self::$db->query($sql);
         $row = $result->fetchAll(PDO::FETCH_ASSOC);

         return $row;

        } catch(PDOExepction $e){
         return $e->getMessage();
        }
    }

    function delete($sql)
    {
        $prepare = self::$db->prepare($sql);
        $prepare->execute();
        return intval($prepare->rowCount());
    }
    function update($sql)
    {
        //echo $sql;
        $prepare = self::$db->prepare($sql);
        $prepare->execute();
        return intval($prepare->rowCount());
    }
}




?>