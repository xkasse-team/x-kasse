<?php

class DB
{
    /**
     * stores established database connection
     * @var mysqli connection
     */
    public static $db = null;

    /**
     * id of last inserted row
     * @var string
     */
    public static $insertID;

    /**
     * initialise db connection
     * @param  string	 $dbHost	 db host
     * @param  string	 $dbUser	 db user
     * @param  string	 $dbPassword db password
     * @param  string	 $dbName	 db name
     */
    public static function init($dbHost, $dbUser, $dbPassword, $dbName) {
        self::$db = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
        if (self::$db->connect_errno) {
            $_SESSION['errors'][] = "MySQL connection failed: ". self::$db->connect_error;
        }
        self::$db->query("SET NAMES utf8;");
    }

    function insert($sql)
    {
        if(mysqli_query(self::$db,$sql)===TRUE)
        {
            $j = mysqli_warning_count(self::$db);

            if ($j > 0 && intval(mysqli_insert_id(self::$db))==0 )
            {
                return 'error at: '.print_r(mysqli_get_warnings(self::$db),true);
            }

            if(intval(mysqli_insert_id(self::$db))==0)
            {
                return 0;
            }
            else
            {
                return mysqli_insert_id(self::$db);
            }
        }
        else
        {
            return mysqli_error(self::$db);
        }
        return 0;
    }

    function fetcharray($sql)
    {
        $result = mysqli_query(self::$db,$sql);

        $array = array();

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
        {
            $array[] = $row;
        }
        if(count($array)>=1)
        {
            return $array;
        }
        else
        {
            return false;
        }
    }

    function delete($sql)
    {
        if(mysqli_query(self::$db,$sql)===TRUE)
        {
            $j = mysqli_warning_count(self::$db);
            if ($j > 0)
            {
                return 'error at: '.$sql.print_r(mysqli_get_warnings(self::$db),true);
            }
            if(intval(mysqli_affected_rows(self::$db))==0)
            {
                return 0;
            }
            else
            {
                return mysqli_affected_rows(self::$db);
            }
        }
        else
        {
            return mysqli_error(self::$db);
        }
        return 0;
    }
    function update($sql)
    {
        if(mysqli_query(self::$db,$sql)===TRUE)
        {
            $j = mysqli_warning_count(self::$db);
            if ($j > 0)
            {
                return 'error at: '.$sql.print_r(mysqli_get_warnings(self::$db),true);
            }
            if(intval(mysqli_affected_rows(self::$db))==0)
            {
                return 0;
            }
            else
            {
                return mysqli_affected_rows(self::$db);
            }
        }
        else
        {
            return mysqli_error(self::$db);
        }
        return 0;
    }


}




?>